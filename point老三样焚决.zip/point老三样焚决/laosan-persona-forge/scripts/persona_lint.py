#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""人格体检：查 AI 味、结构缺失、节奏单调。

用法：
    python persona_lint.py 人格文件.md
    python persona_lint.py 人格文件.md --identity-file id.txt
    python persona_lint.py 人格文件.md --min-score 85

退出码：得分低于 min-score 时为 1，否则 0。
"""

import argparse
import io
import os
import re
import statistics
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


# ---------- 词表 ----------

A_WORDS = [
    "此外", "然而", "综上所述", "总而言之", "值得注意的是", "更重要的是",
    "众所周知", "毋庸置疑", "不言而喻", "诚然", "显而易见", "由此可见",
    "归根结底", "总的来说", "综上", "总之",
    "作为一个ai", "语言模型", "我的设定是", "根据我的设定", "我被设计成",
    "客观来说", "客观地讲", "理性来看", "从某种角度讲", "在一定程度上",
    "因人而异", "相对而言",
    "赋能", "底层逻辑", "闭环", "抓手", "链路", "赛道", "护城河",
    "认知升级", "降维打击", "颗粒度",
    "不可或缺", "至关重要", "意义深远",
]

B_WORDS = ["其实", "说实话", "老实说", "怎么说呢", "某种程度上", "某种意义上", "不得不说"]

C_WORDS = [
    "仿佛", "犹如", "宛若", "一丝", "一抹", "些许", "几分", "隐约",
    "不禁", "微微", "轻轻", "淡淡", "眼中闪过", "嘴角勾起", "眉头微皱",
    "心中一动", "不由得", "心头一震", "瞳孔微缩",
]

ADJ_WORDS = [
    "温柔", "善良", "可爱", "傲娇", "高冷", "活泼", "开朗", "内向",
    "成熟", "稳重", "体贴", "细腻", "毒舌", "幽默", "风趣", "神秘", "冷静", "热情",
]

SUMMARY_TAILS = ["所以", "因此", "总之", "综上", "这说明", "由此可见", "总的来说", "说到底"]

PROHIBIT_MARKERS = ["不要", "不许", "禁止", "别用", "禁用", "避免", "绝不", "不准", "不得", "不用"]

# 三段是老三样插件强依赖的，缺失直接 FAIL
REQUIRED_SECTIONS = [
    ("人称", "人称与身份"),
    ("亲近", "亲近程度"),
    ("心情", "此刻的心情"),
]

# 其余段落缺失只提示，不扣分
OPTIONAL_SECTIONS = [
    ("元层", "元层前提"),
    ("人形", "人形与称谓"),
    ("核心驱动", "核心驱动"),
    ("矛盾", "矛盾与缺陷"),
    ("语言指纹", "语言指纹"),
    ("表达落差", "表达落差"),
    ("社交位", "群内社交位"),
    ("状态", "状态与漂移"),
    ("意外", "意外性协议"),
    ("记忆", "记忆与工具"),
    ("表情", "表情与梗"),
    ("红线", "红线与优先级"),
]


# ---------- 工具函数 ----------

def is_prohibition(line: str) -> bool:
    return any(m in line for m in PROHIBIT_MARKERS)


def clean_for_sentences(text: str) -> str:
    """去掉标题、代码块、列表符号，避免把结构标记当成句子。"""
    out = []
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("#") or s.startswith("```") or s.startswith(">"):
            continue
        s = re.sub(r"^[-*+]\s+", "", s)
        s = re.sub(r"^\d+[.、)]\s*", "", s)
        out.append(s)
    return "\n".join(out)


def split_sentences(text: str):
    parts = re.split(r"[。！？!?…；;]+|\n+", clean_for_sentences(text))
    return [p.strip(" \t　“”\"'「」【】（）()") for p in parts if p.strip()]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("--min-score", type=int, default=85)
    args = ap.parse_args()

    if not os.path.exists(args.file):
        print("找不到文件：%s" % args.file)
        return 2

    text = io.open(args.file, encoding="utf-8-sig").read()
    lines = text.splitlines()
    low = text.lower()

    fails, warns, passes = [], [], []

    def add(bucket, code, msg, line=None):
        entry = "[%s] %s" % (code, msg)
        if line:
            entry += "（第 %d 行）" % line
        bucket.append(entry)

    # ---- 1 禁用词 ----
    hits_a = 0
    for i, line in enumerate(lines, 1):
        if is_prohibition(line):
            continue
        for w in A_WORDS:
            if w in line.lower():
                hits_a += 1
                add(fails, "FAIL", "A 档禁用词「%s」" % w, i)
    if hits_a == 0:
        add(passes, "PASS", "无 A 档禁用词（连接词 / 破戏词 / 黑话）")

    # ---- 2 破折号 ----
    dash_hits = [(i, ln) for i, ln in enumerate(lines, 1)
                 if not is_prohibition(ln) and ("——" in ln or "--" in ln)]
    if dash_hits:
        for i, _ in dash_hits[:5]:
            add(fails, "FAIL", "出现破折号", i)
    else:
        add(passes, "PASS", "零破折号")

    # ---- 3 句式 ----
    if re.search(r"不是[^。！？\n]{1,25}而是", text):
        add(fails, "FAIL", "出现「不是 A 而是 B」否定式排比")
    if "首先" in text and ("其次" in text or "最后" in text):
        add(fails, "FAIL", "出现「首先/其次/最后」三段式")
    if not re.search(r"不是[^。！？\n]{1,25}而是", text) and "首先" not in text:
        add(passes, "PASS", "无否定式排比、无三段式")

    # ---- 4 B 档词频 ----
    total_chars = len(re.sub(r"\s", "", text))
    hits_b = sum(low.count(w) for w in B_WORDS)
    per_k = hits_b / max(total_chars, 1) * 1000
    if per_k > 1.5:
        add(warns, "WARN", "B 档口语词偏多（%.1f 次/千字，上限 1.5）" % per_k)
    else:
        add(passes, "PASS", "B 档口语词频率正常（%.1f 次/千字）" % per_k)

    # ---- 5 小说腔 ----
    hits_c = []
    for i, line in enumerate(lines, 1):
        if is_prohibition(line):
            continue
        for w in C_WORDS:
            if w in line:
                hits_c.append((w, i))
    if hits_c:
        for w, i in hits_c[:5]:
            add(warns, "WARN", "小说腔词「%s」" % w, i)
    else:
        add(passes, "PASS", "无小说腔描写词")

    # ---- 6 句长节奏 ----
    sents = split_sentences(text)
    lens = [len(s) for s in sents if len(s) >= 2]
    if len(lens) >= 8:
        mean = statistics.mean(lens)
        std = statistics.pstdev(lens)
        short_ratio = sum(1 for x in lens if x <= 8) / len(lens)
        if std < 5:
            add(warns, "WARN", "句长标准差 %.1f，节奏偏单调（规则文本建议 ≥5）" % std)
        else:
            add(passes, "PASS", "句长参差正常（标准差 %.1f）" % std)
        if mean > 30:
            add(warns, "WARN", "平均句长 %.1f 字，偏书面腔" % mean)
        if short_ratio < 0.08:
            add(warns, "WARN", "8 字以内短句仅占 %.0f%%，几乎没有短句" % (short_ratio * 100))
        else:
            add(passes, "PASS", "短句占比 %.0f%%" % (short_ratio * 100))
        stats_line = "字数 %d | 句子 %d | 平均句长 %.1f | 标准差 %.1f" % (total_chars, len(lens), mean, std)
    else:
        stats_line = "字数 %d | 句子过少，无法评估节奏" % total_chars
        add(warns, "WARN", "有效句子少于 8 句，无法评估节奏")

    # ---- 7 段末总结 ----
    tail_hits = []
    for i, line in enumerate(lines, 1):
        s = line.strip().rstrip("。！？.!?")
        if not s or is_prohibition(line):
            continue
        if any(s.endswith(t) or s.endswith(t + "了") for t in SUMMARY_TAILS):
            tail_hits.append(i)
    if tail_hits:
        for i in tail_hits[:4]:
            add(warns, "WARN", "句子以总结词收尾", i)
    else:
        add(passes, "PASS", "无总结式收尾")

    # ---- 8 形容词密度 ----
    adj = sum(low.count(w) for w in ADJ_WORDS)
    adj_per_k = adj / max(total_chars, 1) * 1000
    if adj_per_k > 8:
        add(warns, "WARN", "性格形容词密度 %.1f 次/千字，偏高（建议 <8，改写成行为）" % adj_per_k)
    else:
        add(passes, "PASS", "形容词密度 %.1f 次/千字" % adj_per_k)

    # ---- 9 台词示例（只统计"示例/例如"之后引出的，描述性引号不算）----
    explicit = []
    for i, line in enumerate(lines):
        if not any(mk in line for mk in ("示例", "例如", "比如", "示范", "如：")):
            continue
        for m in re.finditer(r"[「“\"]([^」”\"]{4,})[」”\"]", line):
            explicit.append((m.group(1), i + 1))
        nxt = lines[i + 1] if i + 1 < len(lines) else ""
        for m in re.finditer(r"[「“\"]([^」”\"]{4,})[」”\"]", nxt):
            explicit.append((m.group(1), i + 2))
    if len(explicit) > 2:
        for q, i in explicit[:4]:
            add(warns, "WARN", "台词示例「%s…」" % q[:14], i)
        add(warns, "WARN", "台词示例 %d 条，超过 2 条会被模型当模板复用" % len(explicit))
    else:
        add(passes, "PASS", "台词示例 %d 条，在安全范围" % len(explicit))

    # ---- 10 句首重复 ----
    starts = {}
    for s in sents:
        key = s[:2]
        if len(key) >= 2:
            starts[key] = starts.get(key, 0) + 1
    rep = [(k, v) for k, v in starts.items() if v >= 5]
    if rep:
        add(warns, "WARN", "句首重复：%s" % "、".join("「%s」×%d" % (k, v) for k, v in rep[:3]))
    else:
        add(passes, "PASS", "无明显句首重复")

    # ---- 11 结构完整性 ----
    missing_req = [name for key, name in REQUIRED_SECTIONS if key not in text]
    if missing_req:
        for name in missing_req:
            add(fails, "FAIL", "缺插件依赖段：%s" % name)
    else:
        add(passes, "PASS", "三段插件依赖段齐全")

    missing_opt = [name for key, name in OPTIONAL_SECTIONS if key not in text]
    if len(missing_opt) > 3:
        add(warns, "WARN", "缺 %d 个常规段落（%s…）" % (len(missing_opt), "、".join(missing_opt[:3])))
    else:
        add(passes, "PASS", "常规段落基本齐全")

    # ---- 12 字数 ----
    if total_chars > 3200:
        add(warns, "WARN", "正文 %d 字，超过 3200 会被上下文稀释" % total_chars)
    elif total_chars < 1500:
        add(warns, "WARN", "正文 %d 字，偏薄（建议 2000-3000）" % total_chars)

    # ---- 打分 ----
    # FAIL 是硬伤，每条扣 12；WARN 是打磨项，总扣分上限 18，避免细节噪音把好人格压死。
    warn_penalty = min(18, 3 * len(warns))
    score = 100 - 12 * len(fails) - warn_penalty
    score = max(0, min(100, score))
    if score >= 90:
        grade = "A（可直接用）"
    elif score >= 85:
        grade = "B（可用，建议修 WARN）"
    elif score >= 70:
        grade = "C（要改，FAIL 必须清零）"
    else:
        grade = "D（重写）"

    print("=" * 56)
    print("人格体检：%s" % os.path.basename(args.file))
    print(stats_line)
    print("=" * 56)
    for bucket, title in ((fails, "必须改"), (warns, "建议改"), (passes, "通过")):
        if not bucket:
            continue
        print("\n-- %s (%d) --" % (title, len(bucket)))
        for e in bucket:
            print("  " + e)
    print("\n得分：%d / 100   评级：%s" % (score, grade))
    if not fails:
        print("提醒：脚本查不出「读三遍能猜出下一句」这种问题，交付前自己读一遍。")

    return 0 if score >= args.min_score else 1


if __name__ == "__main__":
    sys.exit(main())
