# 调研来源

按"用到了什么"排列，不是书单。

---

## 一、AstrBot 人设实战

- **适用于单模型角色扮演第一人称人设的写作参考**（Yuimi-chaya）
  https://github.com/Yuimi-chaya/Yuimi-chaya.github.io/blob/main/src/content/blog/astrbot-roleplay-persona-notes.md
  取用：分板块写 system prompt；正面示例会被复用，反例更好；工具调用会让人物切回助手腔。

- **人设进阶：把「设定」变成「能演的角色」**（wwwangzilin/dsh-character-presets）
  https://github.com/wwwangzilin/dsh-character-presets/blob/main/persona-template/ADVANCED.md
  取用：形容词 vs 动作的对照；给情绪留出口；危险人设要配红线。

---

## 二、反 AI 味

- **去 AI 味完整模式库**（Lniosy/qiqing-liuyu）
  https://github.com/Lniosy/qiqing-liuyu/blob/main/references/de-ai-patterns.md
  取用：连接词替换表、否定式排比、三段式、破折号零容忍。

- **AI 味禁用词与句式表**（uu201/character-arc）
  https://github.com/uu201/character-arc/blob/main/resources/skills/oh-story-claudecode/story-long-write/references/banned-words.md
  取用：小说腔词表（仿佛/一丝/眼中闪过…）。这些在小说里能用，群聊里没人这样形容自己。

- **Poppet Anti-Slop Preset**（Huzderu/poppet-rp-framework）
  https://github.com/Huzderu/poppet-rp-framework
  取用：AI 写作失败模式清单（复读用户的话、角色全知、情节停滞）。

---

## 三、"活人感"的机制来源

- **顺从是虚拟爱情的坟墓：论 AI 伴侣的"人格缺陷"设计**
  https://tsight.io/articles/20214096
  取用：温度不等于人格波动；独立目标；非线性好感度；拒绝机制。

- **给 AI 装一个人格，为什么装了半天还是穿帮**（Deep Persona 报道）
  https://c.m.163.com/news/a/L9DAO51U0511DTVV.html
  取用：三层人格架构（外部表达 / 中间信念 / 内部动机）。

- **The Stability of Role in LLM Prompting**
  https://tekkix.com/articles/ai/2026/02/the-stability-of-role-in-llm-prompting-on-the
  取用：**自我描述和行为策略是两件事**。角色是生成风格，不是决策机制。本 skill 最重要的一条依据。

---

## 四、群聊专属

- **ThinkMate 的 persona.md（群聊段落）**
  https://github.com/TechShreyash/ThinkMate/blob/main/persona.md
  取用：不需要每条都回；分清谁在说话；群聊回复比私聊更短。

- **SillyTavern 群聊提示词指南**
  http://relationshipdot.com/how-to-use-advanced-system-prompts-to-force-group-chats-in-sillytavern
  取用：多角色场景要显式锁定"我只扮演谁"，否则会串台。

---

## 五、老三样插件的一手结论（读源码得出，非二手教程）

### self_learning

- 好感度与情绪通过 `extra_user_content_parts` 注入，包裹成 `<context>…</context>`，
  内容是 `【对该用户的好感度】好感度: X/100 (描述)` 和 `【Bot当前情绪状态】情绪: xxx (强度 n) - 描述`。
- **好感度只在 @ 或唤醒消息时结算**（`main.py` 里 `if event.is_at_or_wake_command`），
  普通群聊不结算，所以"聊得多就涨"是错的。
- 分值表：chat +1 / compliment +3 / praise +5 / flirt +5 / gift +8；
  insult -8 / harassment -6 / abuse -10 / threat -12。
- 交互类型由 **LLM 分类**（走 filter 模型），提示词明确"不确定时优先积极或 chat"。
- 情绪数值分档写死在代码里（0/20/40/60/80），所以人格必须按同样的档位写行为，
  否则 45 分和 0 分在行为上没有差别（实测）。
- **好感度下限被钳在 0**（`max(0, min(new_level, 100))`），负数档永远不会出现。
- `get_mood_influenced_system_prompt` 里有一整套情绪→语气映射，但只在
  `intelligent_responder` 这条支线里调用，主链路不用它。所以情绪不会自动改变说话方式。

### livingmemory

- 记忆以 `extra_user_content` 注入（唯一支持的方式，其它方式已废弃并自动回退）。
- 注入内容是第三人称叙述，容易和"当前说话人"混淆，人格的人称段必须兜住。
- 支持向量 + 图记忆双路召回，rerank 可选（填 provider id，不是模型名）。

### group_chat_plus

- 上下文以 `名字(ID:用户ID): 内容` 平铺，自己的回复标 `【禁止重复-你的历史回复】`。
- 额外注入 `[系统信息-当前对话对象] 名字（ID:xxx）`。
- `is_at_message` 有 bug：At 组件被平台剥离后扫不到，文本兜底又拿平台名当昵称，
  导致 `@昵称` 匹配失败，@ 消息退化成普通消息走概率（详见部署 skill）。
- 概率只应作用于非 @ 消息；`initial_probability` 是"读空气"的基础概率。
