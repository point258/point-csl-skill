---
name: astrbot-qq-deploy
description: 在 Linux 服务器上用 Docker 从零部署 AstrBot + NapCat 的 QQ 群聊机器人，并配置老三样插件（group_chat_plus 读空气 / livingmemory 长期记忆 / self_learning 好感度与心情 / smart_segmentation 分段）、模型分工、人格接入、验收与排障。当需要部署 QQ 机器人、配置 AstrBot、或排查"bot 不说话/不回 @/人格不生效"时使用。配合《老三样人格生成器》产出人格。
agent_created: true
---

# AstrBot + QQ 机器人部署

从一台空服务器，到群里能正常说话的 bot。全程命令行，不依赖任何特定客户端。

**这个 skill 不绑定 harness。** 下面所有操作都是标准 shell、HTTP、SQL。
你的环境如果提供 SSH 工具就用，没有就用 `ssh` / `scp` 命令行，或 `scripts/ssh_helper.py`（仅依赖 paramiko）。

---

## 开始之前：先确认信息够不够

**这一步不能跳。** 信息不全就配置出来的东西一定是错的，浪费双方时间。

### 必须拿到的（缺一项就停下来问）

| 项 | 为什么要 |
|---|---|
| 服务器地址 / SSH 端口 / 用户 / 密码或密钥 | 没这个什么都做不了 |
| 要挂的 QQ 号（昵称） | 人格的"人称锚"要用它，否则 bot 分不清哪句是自己说的 |
| 模型服务：base_url + api_key + 模型名 | 至少三个槽位：对话、快速/识图、高推理 |
| 角色设定：是谁 + 什么群 + 不能碰的线 | 人格的根本输入 |
| 服务器是否已装过 AstrBot / 有没有数据要保留 | 决定是全新装还是迁移 |

### 可以推断的（推断后在交付里注明，不要问）

- 部署目录（默认 `/opt/bots`）
- 时区（默认 `Asia/Shanghai`）
- 端口（AstrBot 6185/6199、NapCat 6099、面板 7833）
- 插件版本（用最新稳定版）
- 好感度/心情参数（用文档里的推荐值）

### 提问纪律

1. **一次问全。** 把缺的项合并成一组问题（最多 4 条），不要挤牙膏式追问。
2. **首轮已给的不要重问。** 用户说过"服务器是 1.2.3.4，密码 xxx，想做猫娘"，就只问剩下的。
3. **信息不足就停。** 不要猜密码、不要猜模型名、不要用假数据先跑起来。
4. **用户说"你看着办"。** 用推荐默认值，并在交付时列出"我替你决定了什么"，给回滚方式。

详细判定表见 `references/00-intake.md`。

---

## 部署流程（8 步）

### Step 1 环境检查

```bash
uname -a; cat /etc/os-release | head -3
docker --version; docker compose version
free -h; df -h /
ss -lntp | grep -E '6185|6199|6099|7833'
```

要求：Docker ≥ 24，内存 ≥ 1G（1G 机器要开 swap），上述端口未被占用。

### Step 2 起容器

用 `assets/docker-compose.yml.tpl` 生成 `/opt/bots/docker-compose.yml`，
两个服务：`napcat`（QQ 协议端）和 `astrbot`（机器人本体），共享一个 bridge 网络。

```bash
cd /opt/bots && docker compose up -d
docker compose ps
```

细节与端口/安全组说明见 `references/10-server-docker.md`。

### Step 3 登录 QQ

NapCat 首次启动会生成二维码：

```bash
docker restart napcat && sleep 16
docker exec napcat base64 -w0 /app/napcat/cache/qrcode.png | base64 -d > /tmp/qr.png
```

把二维码给用户扫。扫码成功后 NapCat 日志会出现账号昵称。
**记下这个昵称**——人格的【人称与身份】段要用。

### Step 4 配置 NapCat 反向连接

确保 `/app/napcat/config/onebot11.json` 里有指向 AstrBot 的 websocket 客户端：

```json
{"enable": true, "url": "ws://astrbot:6199/ws", "token": "", "messagePostFormat": "array"}
```

### Step 5 配置模型 Provider

AstrBot 的 provider 分两层：`provider_sources`（地址+密钥）和 `provider`（模型+模态）。
至少三个：

| 槽位 | 用途 |
|---|---|
| 对话主模型 | 平时说话 |
| 快速模型 | 读空气判断、分段、识图 |
| 高推理模型 | 记忆整理、学习提炼（可开 reasoning_effort=high） |

写完直接改 `data/cmd_config.json`（容器停掉再改，或改完重启）。
细节见 `references/30-astrbot-core.md`。

### Step 6 装插件并配置

四个插件：`group_chat_plus`、`livingmemory`、`self_learning`、`smart_segmentation`。
每个都有必填的 provider 槽位，留空会用错模型（甚至用最贵的那个）。

配置矩阵与踩坑见 `references/40-plugins.md`。
**必须打的补丁**用 `scripts/patch_plugins.py` 一键应用（见 Step 8）。

### Step 7 接入人格

1. 用《老三样人格生成器》（`laosan-persona-forge`）产出人格正文。
2. 写进 AstrBot 的 `personas` 表，或 WebUI 里新建人格。
3. 设为默认：`agent_runner.config.persona.persona_id`。

**人格必须包含【人称与身份】【亲近程度】【此刻的心情】三段**，
否则三个插件注入的好感度/情绪全是白费。

### Step 8 打补丁 + 验收

```bash
python scripts/patch_plugins.py --all      # 应用已知修复
python scripts/verify_deploy.py            # 逐项验收
```

验收清单见 `references/50-verify.md`，常见故障见 `references/60-troubleshooting.md`。

---

## 必打的 5 个补丁（否则一定有毛病）

这些是插件本身的 bug，不是配置问题。`scripts/patch_plugins.py` 会全部处理：

| # | 插件 | 问题 | 影响 |
|---|---|---|---|
| 1 | group_chat_plus | `is_at_message` 扫不到 At 组件、文本兜底又用平台名当昵称 | **@ 她不回**，@ 消息被当普通消息走概率 |
| 2 | self_learning | `save_bot_mood` 不写 `end_time` | 心情时长永远按 24h 算 |
| 3 | self_learning | 心情过期不重建（只读不写） | 心情 24h 后**彻底停止更新** |
| 4 | self_learning | 事件驱动心情固定 4h | 与"定时刷新"冲突 |
| 5 | self_learning | `affection_status` 排行榜不排序 | 榜单按录入顺序，不是按分数 |

另外 `scripts/patch_plugins.py --daily-cap 10` 可加"每日好感度净增上限"（默认不加）。

---

## 关键配置速查

| 键 | 推荐值 | 为什么 |
|---|---|---|
| `provider_ltm_settings.group_icl_enable` | true | 群聊上下文感知，group_chat_plus 硬性要求 |
| `provider_ltm_settings.group_message_history_enable` | true | 同上 |
| `platform_settings.empty_mention_waiting` | **false** | 与插件等待窗口冲突，会认错发送者 |
| `platform_settings.segmented_reply.enable` | false | 交给 smart_segmentation，别双重分段 |
| `agent_runner.config.compression.max_turns` | 24 | 1 turn = 1 问 1 答；防旧人格惯性，且不删数据 |
| `agent_runner.config.model.fallback_provider_ids` | [高推理模型] | 主模型挂了不至于哑掉 |
| `admins_id` | [管理员QQ] | 管理命令权限 |
| `group_chat_plus.initial_probability` | 0.05~0.10 | 主动接话频率；0.02 几乎不冒泡 |

---

## 交付时必须说明的

1. **改了什么配置**（列成表，附文件路径）
2. **打了哪些补丁**（升级插件会覆盖，要重打）
3. **怎么改人格、改完怎么让它立刻生效**（`/gcp_reset_here` 或 `/new`，别用 `/reset`）
4. **重启/重建容器的代价**（重建会丢容器内 pip 装的依赖）
5. **备份在哪**

运维流程见 `references/70-ops.md`。

---

## 参考文件

- `references/00-intake.md` — 信息收集清单与判定表
- `references/10-server-docker.md` — 服务器、compose、端口、安全组
- `references/20-napcat-qq.md` — NapCat 登录、二维码、OneBot 连接
- `references/30-astrbot-core.md` — AstrBot 核心配置逐项说明
- `references/40-plugins.md` — 四个插件的作用、槽位、坑
- `references/50-verify.md` — 验收清单（15 项 + 模型连通性）
- `references/60-troubleshooting.md` — 症状 → 根因 → 修法
- `references/70-ops.md` — 备份、清理、改人格、升级
- `assets/docker-compose.yml.tpl` — 编排模板
- `scripts/ssh_helper.py` — 无 SSH 工具时的兜底
- `scripts/patch_plugins.py` — 一键打补丁
- `scripts/verify_deploy.py` — 一键验收
