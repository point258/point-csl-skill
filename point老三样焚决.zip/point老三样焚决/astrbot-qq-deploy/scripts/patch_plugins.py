#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""给 group_chat_plus / self_learning 打已知修复补丁。

用法（在服务器上执行，容器可以运行）：
    python patch_plugins.py --check        # 只看哪些补丁缺失
    python patch_plugins.py --all          # 打全部基础补丁
    python patch_plugins.py --at-fix       # 只修 @ 判定
    python patch_plugins.py --mood         # 只修心情三处
    python patch_plugins.py --rank         # 只修好感度排行榜
    python patch_plugins.py --daily-cap 10 # 加每日净增上限（默认不加）
    python patch_plugins.py --base /path/to/plugins

每个被改的源文件都会留 .bak-<时间戳>。
"""
import argparse
import io
import json
import os
import shutil
import time

STAMP = time.strftime("%Y%m%d-%H%M%S")
GCP = "astrbot_plugin_group_chat_plus"
SL = "astrbot_plugin_self_learning"


def read(p):
    return io.open(p, encoding="utf-8").read()


def write(p, s):
    io.open(p, "w", encoding="utf-8").write(s)


def backup(p):
    bak = p + ".bak-" + STAMP
    if not os.path.exists(bak):
        shutil.copy2(p, bak)


def sub(path, old, new, label, *, count=1, dry=False, sentinel=None):
    """精确替换；命中次数不等于 count 就跳过，不瞎改。

    sentinel 用来判断"是否已打过"，缺省用 new 的片段。整段比对容易被注释差异干扰，
    建议显式给一个稳定的特征串。
    """
    if not os.path.exists(path):
        print("  跳过 %-28s 文件不存在" % label)
        return None
    s = read(path)
    probe = sentinel if sentinel else new
    if probe in s:
        print("  已是 %-26s 无需处理" % label)
        return True
    n = s.count(old)
    if n != count:
        print("  跳过 %-28s 匹配 %d 次（预期 %d）" % (label, n, count))
        return None
    if dry:
        print("  缺失 %-28s" % label)
        return False
    backup(path)
    write(path, s.replace(old, new))
    print("  已打 %-28s" % label)
    return True


# ---------------------------------------------------------------- @ 判定

def patch_at(base, dry=False):
    p = os.path.join(base, GCP, "utils/message_processor.py")
    old = """        try:
            # 方法1: 检查消息链中是否有At组件指向机器人（优先使用）"""
    new = """        try:
            # 补丁：AstrBot 唤醒阶段会剥离 At 组件，组件扫描会漏判；
            # is_at_or_wake_command 是平台给出的权威标志，优先采信。
            if getattr(event, "is_at_or_wake_command", False):
                return True

            # 方法1: 检查消息链中是否有At组件指向机器人（优先使用）"""
    return sub(p, old, new, "@消息判定", dry=dry,
               sentinel="is_at_or_wake_command")


# ---------------------------------------------------------------- 心情

def patch_mood(base, hours=2, dry=False):
    r = []
    p1 = os.path.join(base, SL, "services/database/facades/affection_facade.py")
    r.append(sub(
        p1,
        """                    'start_time': time.time(),
                })""",
        """                    'start_time': time.time(),
                    'end_time': time.time() + duration_hours * 3600,
                })""",
        "心情写入 end_time", dry=dry,
        sentinel="'end_time': time.time() + duration_hours * 3600",
    ))

    p2 = os.path.join(base, SL, "services/social/social_context_injector.py")
    r.append(sub(
        p2,
        "mood_raw = await self.mood_manager.get_current_mood(group_id)",
        "mood_raw = await self.mood_manager.ensure_mood_for_group(group_id)",
        "心情过期自动换新", dry=dry,
        sentinel="ensure_mood_for_group(group_id)",
    ))

    p3 = os.path.join(base, SL, "services/state/affection_manager.py")
    r.append(sub(
        p3,
        "description, 4)  # 持续4小时",
        "description, %d)  # 最长%d小时" % (hours, hours),
        "事件驱动心情上限", dry=dry,
        sentinel="# 最长%d小时" % hours,
    ))
    return r


# ---------------------------------------------------------------- 排行榜

def patch_rank(base, dry=False):
    r = []
    p1 = os.path.join(base, SL, "services/state/affection_manager.py")
    if os.path.exists(p1):
        s = read(p1)
        marker = "'top_users': all_affections[:5]"
        if "sorted(" in s and "affection_level" in s and marker not in s:
            print("  已是 排行榜排序                  无需处理")
        elif marker in s:
            if not dry:
                backup(p1)
                s = s.replace(
                    "                'top_users': all_affections[:5],  # 前5名",
                    "                'top_users': sorted(\n"
                    "                    all_affections,\n"
                    "                    key=lambda a: a.get('affection_level', 0),\n"
                    "                    reverse=True,\n"
                    "                )[:5],  # 按好感度降序",
                )
                write(p1, s)
                print("  已打 排行榜排序")
            else:
                print("  缺失 排行榜排序")
        else:
            print("  跳过 排行榜排序                  未找到目标行")

    p2 = os.path.join(base, SL, "services/commands/handlers.py")
    if os.path.exists(p2):
        s = read(p2)
        if 'top_users"][:5]' in s:
            print("  已是 排行榜显示条数               无需处理")
        elif 'top_users"][:3]' in s:
            if not dry:
                backup(p2)
                write(p2, s.replace('top_users"][:3]', 'top_users"][:5]'))
                print("  已打 排行榜显示条数")
            else:
                print("  缺失 排行榜显示条数")
    return r


# ---------------------------------------------------------------- 每日上限

def patch_daily_cap(base, cap=10, dry=False):
    """每日净增上限：当天最多涨 cap 点，掉的分可以补回来。"""
    sl = os.path.join(base, SL)
    r = []

    r.append(sub(
        os.path.join(sl, "config.py"),
        "    mood_affect_affection: bool = True # 情绪影响好感度变化",
        "    mood_affect_affection: bool = True # 情绪影响好感度变化\n"
        "    daily_affection_cap: int = %d # 每日好感度净增上限（掉分可补回）" % cap,
        "config 字段", dry=dry, sentinel="daily_affection_cap"))

    r.append(sub(
        os.path.join(sl, "config.py"),
        "            mood_affect_affection=affection_settings.get('mood_affect_affection', True),",
        "            mood_affect_affection=affection_settings.get('mood_affect_affection', True),\n"
        "            daily_affection_cap=int(affection_settings.get('daily_affection_cap', %d))," % cap,
        "config 解析", dry=dry, sentinel="daily_affection_cap=int("))

    r.append(sub(
        os.path.join(sl, "repositories/affection_repository.py"),
        "from sqlalchemy import select, and_",
        "from sqlalchemy import select, and_, func, case",
        "repository 导入", dry=dry, sentinel="and_, func, case"))

    r.append(sub(
        os.path.join(sl, "repositories/affection_repository.py"),
        """    async def create_interaction(
        self,
        group_id: str,
        user_id: str,
        interaction_type: str,
        affection_delta: int,
        message: str = None
    ) -> Optional[AffectionInteraction]:""",
        """    async def create_interaction(
        self,
        user_affection_id: int,
        interaction_type: str,
        affection_delta: int,
        message: str = None
    ) -> Optional[AffectionInteraction]:""",
        "repository 签名", dry=dry, sentinel="user_affection_id: int,"))

    r.append(sub(
        os.path.join(sl, "repositories/affection_repository.py"),
        """        return await self.create(
            group_id=group_id,
            user_id=user_id,
            interaction_type=interaction_type,
            affection_delta=affection_delta,
            message=message,
            timestamp=int(time.time())
        )""",
        """        return await self.create(
            user_affection_id=user_affection_id,
            interaction_type=interaction_type,
            affection_delta=affection_delta,
            message_content=(message or None),
            timestamp=int(time.time())
        )

    async def get_daily_totals(self, user_affection_id: int, since_ts: int) -> tuple:
        \"\"\"返回 (今日加分合计, 今日扣分合计绝对值)\"\"\"
        stmt = select(
            func.coalesce(func.sum(case((AffectionInteraction.affection_delta > 0,
                                         AffectionInteraction.affection_delta), else_=0)), 0),
            func.coalesce(func.sum(case((AffectionInteraction.affection_delta < 0,
                                         -AffectionInteraction.affection_delta), else_=0)), 0),
        ).where(and_(
            AffectionInteraction.user_affection_id == user_affection_id,
            AffectionInteraction.timestamp >= since_ts,
        ))
        row = (await self.session.execute(stmt)).first()
        return (int(row[0] or 0), int(row[1] or 0)) if row else (0, 0)""",
        "repository 实现", dry=dry, sentinel="async def get_daily_totals"))

    # facade：导入 + 两个方法
    r.append(sub(
        os.path.join(sl, "services/database/facades/affection_facade.py"),
        "    from ....repositories.affection_repository import AffectionRepository",
        "    from ....repositories.affection_repository import AffectionRepository, InteractionRepository",
        "facade 导入(包内)", dry=dry, sentinel="AffectionRepository, InteractionRepository"))
    r.append(sub(
        os.path.join(sl, "services/database/facades/affection_facade.py"),
        "    from repositories.affection_repository import AffectionRepository",
        "    from repositories.affection_repository import AffectionRepository, InteractionRepository",
        "facade 导入(绝对)", dry=dry, sentinel="from repositories.affection_repository import AffectionRepository, InteractionRepository"))
    r.append(sub(
        os.path.join(sl, "services/database/facades/affection_facade.py"),
        """        except Exception as e:
            self._logger.error(f"[AffectionFacade] 更新好感度失败: {e}")
            return False""",
        """        except Exception as e:
            self._logger.error(f"[AffectionFacade] 更新好感度失败: {e}")
            return False

    async def record_affection_interaction(
        self, group_id: str, user_id: str, interaction_type: str,
        delta: int, message: str = "",
    ) -> bool:
        \"\"\"记录一条好感度变动明细，供每日上限统计\"\"\"
        try:
            async with self.get_session() as session:
                repo = AffectionRepository(session)
                affection = await repo.get_by_group_and_user(group_id, user_id)
                if not affection:
                    return False
                irepo = InteractionRepository(session)
                await irepo.create_interaction(affection.id, interaction_type, delta, message)
                return True
        except Exception as e:
            self._logger.error(f"[AffectionFacade] 记录好感度明细失败: {e}")
            return False

    async def get_daily_affection_totals(
        self, group_id: str, user_id: str, since_ts: int,
    ) -> tuple:
        \"\"\"返回该用户今日 (加分合计, 扣分合计)\"\"\"
        try:
            async with self.get_session() as session:
                repo = AffectionRepository(session)
                affection = await repo.get_by_group_and_user(group_id, user_id)
                if not affection:
                    return 0, 0
                irepo = InteractionRepository(session)
                return await irepo.get_daily_totals(affection.id, since_ts)
        except Exception as e:
            self._logger.error(f"[AffectionFacade] 读取每日好感度统计失败: {e}")
            return 0, 0""",
        "facade 方法", dry=dry, sentinel="record_affection_interaction"))

    # db manager 转发
    r.append(sub(
        os.path.join(sl, "services/database/sqlalchemy_database_manager.py"),
        """    async def get_total_affection(self, group_id: str) -> int:
        return await self._affection.get_total_affection(group_id)""",
        """    async def get_total_affection(self, group_id: str) -> int:
        return await self._affection.get_total_affection(group_id)

    async def record_affection_interaction(
        self, group_id: str, user_id: str, interaction_type: str,
        delta: int, message: str = "",
    ) -> bool:
        return await self._affection.record_affection_interaction(
            group_id, user_id, interaction_type, delta, message
        )

    async def get_daily_affection_totals(
        self, group_id: str, user_id: str, since_ts: int,
    ):
        return await self._affection.get_daily_affection_totals(group_id, user_id, since_ts)""",
        "db manager 转发", dry=dry, sentinel="get_daily_affection_totals"))

    # 主逻辑：上限判定 + 落明细
    r.append(sub(
        os.path.join(sl, "services/state/affection_manager.py"),
        """            new_level = current_level + change_result['change']
            new_level = max(0, min(new_level, self.config.max_user_affection))
""",
        """            new_level = current_level + change_result['change']
            new_level = max(0, min(new_level, self.config.max_user_affection))

            # 每日净增上限：当天最多涨 cap 点；当天掉过多少，就能多补回多少
            if new_level > current_level:
                daily_cap = int(getattr(self.config, "daily_affection_cap", %d) or %d)
                today_start = int(
                    datetime.now().replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
                )
                gain_today, loss_today = await self.db_manager.get_daily_affection_totals(
                    group_id, user_id, today_start
                )
                allowed = daily_cap + loss_today - gain_today
                if allowed <= 0:
                    return {
                        'success': False,
                        'reason': f"今日好感度已达上限（{daily_cap}+掉分补偿{loss_today}，已涨{gain_today}）",
                        'current_level': current_level,
                        'change': 0
                    }
                new_level = current_level + min(new_level - current_level, allowed)
""" % (cap, cap),
        "上限判定", dry=dry, sentinel="daily_affection_cap"))
    r.append(sub(
        os.path.join(sl, "services/state/affection_manager.py"),
        """            if success:
                return {
                    'success': True,
                    'previous_level': current_level,""",
        """            if success and new_level != current_level:
                await self.db_manager.record_affection_interaction(
                    group_id, user_id, interaction_type.value, new_level - current_level, ""
                )

            if success:
                return {
                    'success': True,
                    'previous_level': current_level,""",
        "落明细", dry=dry, sentinel="record_affection_interaction("))

    # 配置 schema（否则插件保存配置时会丢字段）
    sp = os.path.join(base, SL, "_conf_schema.json")
    if os.path.exists(sp):
        d = load_json(sp)
        items = d.get("Affection_System_Settings", {}).get("items", {})
        if "daily_affection_cap" in items:
            print("  已是 schema 字段                    无需处理")
        elif not dry:
            backup(sp)
            new_items = {}
            for k, v in items.items():
                new_items[k] = v
                if k == "max_user_affection":
                    new_items["daily_affection_cap"] = {
                        "description": "每日好感度净增上限",
                        "type": "int",
                        "hint": "每天最多净增多少点；当天掉的分可以补回来（掉12点则当天上限变22）",
                        "default": cap,
                    }
            d["Affection_System_Settings"]["items"] = new_items
            write_json(sp, d)
            print("  已打 schema 字段")
        else:
            print("  缺失 schema 字段")
    return r


def load_json(p):
    return json.load(io.open(p, encoding="utf-8-sig"))


def write_json(p, obj):
    io.open(p, "w", encoding="utf-8").write(
        json.dumps(obj, ensure_ascii=False, indent=2))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="/opt/bots/astrbot/data/plugins")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--at-fix", action="store_true")
    ap.add_argument("--mood", action="store_true")
    ap.add_argument("--rank", action="store_true")
    ap.add_argument("--daily-cap", type=int, default=0)
    a = ap.parse_args()

    dry = a.check
    # 只给 --check 时默认检查全部；给了具体项就只查那项
    if not any([a.all, a.at_fix, a.mood, a.rank, a.daily_cap]):
        a.all = True

    print("插件目录:", a.base)
    if a.check:
        print("模式: 只检查\n")

    if a.all or a.at_fix:
        print("[@ 判定]")
        patch_at(a.base, dry)
    if a.all or a.mood:
        print("[心情]")
        patch_mood(a.base, dry=dry)
    if a.all or a.rank:
        print("[排行榜]")
        patch_rank(a.base, dry)
    if a.daily_cap:
        print("[每日上限]")
        patch_daily_cap(a.base, a.daily_cap, dry)

    print("\n完成。改过的文件都在同目录留了 .bak-<时间戳>。")
    print("升级插件会覆盖这些补丁，升级后重跑本脚本。")


if __name__ == "__main__":
    main()
