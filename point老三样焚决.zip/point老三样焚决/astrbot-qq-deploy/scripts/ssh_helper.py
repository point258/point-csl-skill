#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SSH 兜底工具：当所在环境没有现成的远程执行能力时用它。

只依赖 paramiko（`pip install paramiko`）。

凭据从环境变量读，不要写进命令历史：
    export SSH_HOST=1.2.3.4
    export SSH_PORT=22
    export SSH_USER=root
    export SSH_PASSWORD=xxxx          # 或 SSH_KEY=/path/id_rsa

用法：
    python ssh_helper.py run "docker ps"
    python ssh_helper.py run --file deploy.sh          # 把本地脚本传上去再执行
    python ssh_helper.py put ./local.conf /tmp/remote.conf
    python ssh_helper.py get /tmp/qr.png ./qr.png

注意：Windows 的 Git Bash 会把 /tmp/xxx 翻译成本地路径，
远端路径参数前加 `MSYS_NO_PATHCONV=1`，或改用相对路径。
"""
import argparse
import os
import sys

try:
    import paramiko
except ImportError:
    sys.exit("需要 paramiko：pip install paramiko")


def connect():
    host = os.environ.get("SSH_HOST")
    if not host:
        sys.exit("未设置 SSH_HOST")
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    kw = dict(
        hostname=host,
        port=int(os.environ.get("SSH_PORT", "22")),
        username=os.environ.get("SSH_USER", "root"),
        timeout=30,
        banner_timeout=30,
        allow_agent=False,
        look_for_keys=False,
    )
    key = os.environ.get("SSH_KEY")
    if key:
        kw["key_filename"] = key
        kw.pop("look_for_keys")
    else:
        kw["password"] = os.environ.get("SSH_PASSWORD", "")
    c.connect(**kw)
    return c


def run(cmd, timeout=600):
    c = connect()
    stdin, stdout, stderr = c.exec_command(cmd, timeout=timeout)
    out = stdout.read().decode("utf-8", "replace")
    err = stderr.read().decode("utf-8", "replace")
    code = stdout.channel.recv_exit_status()
    if out:
        print(out, end="")
    if err.strip():
        print(err, file=sys.stderr, end="")
    c.close()
    return code


def put(local, remote):
    c = connect()
    sftp = c.open_sftp()
    sftp.put(local, remote)
    sftp.close()
    c.close()
    print("uploaded", remote, os.path.getsize(local), "bytes")


def get(remote, local):
    c = connect()
    sftp = c.open_sftp()
    sftp.get(remote, local)
    sftp.close()
    c.close()
    print("downloaded", local, os.path.getsize(local), "bytes")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="action", required=True)

    r = sub.add_parser("run")
    r.add_argument("cmd", nargs="?")
    r.add_argument("--file", help="上传本地脚本后执行")
    r.add_argument("--timeout", type=int, default=600)

    p = sub.add_parser("put")
    p.add_argument("local")
    p.add_argument("remote")

    g = sub.add_parser("get")
    g.add_argument("remote")
    g.add_argument("local")

    a = ap.parse_args()

    if a.action == "run":
        if a.file:
            remote = "/tmp/_run_%d.sh" % os.getpid()
            put(a.file, remote)
            return run("bash %s" % remote, a.timeout)
        if not a.cmd:
            sys.exit("需要 cmd 或 --file")
        return run(a.cmd, a.timeout)
    if a.action == "put":
        return put(a.local, a.remote) or 0
    if a.action == "get":
        return get(a.remote, a.local) or 0


if __name__ == "__main__":
    sys.exit(main() or 0)
