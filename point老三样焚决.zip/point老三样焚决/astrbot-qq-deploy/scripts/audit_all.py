import json
import os
import sqlite3
import sys

import argparse

_ap = argparse.ArgumentParser()
_ap.add_argument("--data", default="/opt/bots/astrbot/data")
_A = _ap.parse_args()

D = _A.data.rstrip("/")
CONF = D + "/config"
REQ = D + "/plugin_data/astrbot_plugin_diary/requests.log"

rows = []


def ok(cond, name, detail=""):
    rows.append((bool(cond), name, detail))


def load(p, default=None):
    try:
        return json.load(open(p, encoding="utf-8-sig"))
    except Exception:
        return default if default is not None else {}


cmd = load(D + "/cmd_config.json")
gcp = load(CONF + "/astrbot_plugin_group_chat_plus_config.json")
sl = load(CONF + "/astrbot_plugin_self_learning_config.json")
lm = load(CONF + "/astrbot_plugin_livingmemory_config.json")
ar = (cmd.get("agent_runner") or {}).get("config") or {}

# ---------- 核心配置 ----------
ok(ar.get("persona", {}).get("persona_id"), "默认人格", ar.get("persona", {}).get("persona_id"))
ok(ar.get("model", {}).get("provider_id"), "主模型", ar.get("model", {}).get("provider_id"))
ok(ar.get("model", {}).get("fallback_provider_ids"), "兜底链",
   str(ar.get("model", {}).get("fallback_provider_ids")))
ok((ar.get("compression") or {}).get("max_turns") == 24, "历史轮数=24",
   str((ar.get("compression") or {}).get("max_turns")))
ok(cmd.get("provider_ltm_settings", {}).get("group_icl_enable") is True, "群聊上下文 ICL")
ok(cmd.get("platform_settings", {}).get("empty_mention_waiting") is False, "空@等待已关")
ok(cmd.get("platform_settings", {}).get("segmented_reply", {}).get("enable") is False, "平台分段已关")

# ---------- self_learning ----------
ok(sl.get("Runtime_Internal_Settings", {}).get("enable_llm_hooks") is True,
   "注入总开关 enable_llm_hooks")
ok(sl.get("Social_Context_Settings", {}).get("enable_social_context_injection") is True,
   "社交上下文注入")
ok(sl.get("Social_Context_Settings", {}).get("include_affection_info") is True, "包含好感度")
ok(sl.get("Persona_Evolution_Settings", {}).get("enable_persona_evolution") is False, "人格演化已关")
ok(sl.get("Repository_Settings", {}).get("top_patterns_limit") == 4, "表达样本上限=4",
   str(sl.get("Repository_Settings", {}).get("top_patterns_limit")))
ok(sl.get("Affection_System_Settings", {}).get("daily_affection_cap") == 10, "每日好感上限=10")

# ---------- gcp ----------
ok(gcp.get("enable_mood_system") is True, "情绪系统已开")
ok(gcp.get("decision_ai_provider_id"), "读空气模型", gcp.get("decision_ai_provider_id"))
ok(gcp.get("image_to_text_provider_id"), "识图模型", gcp.get("image_to_text_provider_id"))
ok(gcp.get("plugin_gcp_reset_here_allowed_user_ids"), "重置白名单",
   str(gcp.get("plugin_gcp_reset_here_allowed_user_ids")))

# ---------- livingmemory ----------
ok(lm.get("graph_memory", {}).get("enabled") is True, "图谱记忆已开")
ok(lm.get("recall_engine", {}).get("rerank_enabled") is True, "重排已开")
ok(lm.get("provider_settings", {}).get("embedding_provider_id"), "向量模型",
   lm.get("provider_settings", {}).get("embedding_provider_id"))
ok(lm.get("recall_engine", {}).get("top_k") == 5, "召回条数=5")

# ---------- 数据 ----------
p = D + "/plugin_data/astrbot_plugin_self_learning/messages.db"
c = sqlite3.connect("file:%s?mode=ro" % p, uri=True)
ok(c.execute("select count(*) from user_affections").fetchone()[0] > 0, "好感度有数据")
ok(c.execute("select count(*) from style_learning_reviews where status='pending'").fetchone()[0] == 0,
   "无待审学习项")
c.close()

p = D + "/plugin_data/astrbot_plugin_livingmemory/livingmemory.db"
c = sqlite3.connect("file:%s?mode=ro" % p, uri=True)
ok(c.execute("select count(*) from documents").fetchone()[0] > 0, "记忆库有数据",
   str(c.execute("select count(*) from documents").fetchone()[0]))
ok(c.execute("select count(*) from documents where typeof(updated_at)='integer'").fetchone()[0] == 0,
   "记忆时间字段类型正确")
c.close()

# ---------- 实际注入（最重要） ----------
try:
    lines = open(REQ, encoding="utf-8").read().strip().splitlines()
    rec = json.loads(lines[-1])
    blob = rec["system"] + "\n" + rec["prompt"] + "\n" + "\n".join(rec["extra_parts"])
    ok("好感度:" in blob and "/100" in blob, "实际注入：好感度")
    ok("对方情绪" in blob, "实际注入：对方情绪")
    ok("情绪参考" not in blob, "实际注入：无旧情绪参考")
    ok("当前语言风格" not in blob, "实际注入：无随机风格")
    ok("推荐回复模式" not in blob, "实际注入：无随机回复模式")
    ok("你最近的回复历史" in blob, "实际注入：回复避重")
    ok("【对该用户的好感度】" in blob, "实际注入：好感度块完整")
    ok("RAG-Faiss-Memory" in blob, "实际注入：记忆块")
    ok("当时关系" in blob or "【当时关系】" in blob, "实际注入：记忆关系说明")
    ok("Skill" not in rec["system"] and "Available skills" not in rec["system"],
       "实际注入：无技能段（若无 FAIL 属已知遗留）")
    print("采样请求：system=%d, parts=%d, contexts=%d, tools=%d"
          % (len(rec["system"]), len(rec["extra_parts"]),
             len(rec.get("contexts", [])), len(rec.get("tools", []))))
except Exception as e:
    ok(False, "读取实时请求", repr(e)[:60])

# ---------- 输出 ----------
print("\n%-4s %-28s %s" % ("", "检查项", "证据"))
fails = 0
for good, name, detail in rows:
    print("%-4s %-28s %s" % ("PASS" if good else "FAIL", name, detail))
    if not good:
        fails += 1
print("\n通过 %d / 失败 %d" % (len(rows) - fails, fails))
sys.exit(1 if fails else 0)
