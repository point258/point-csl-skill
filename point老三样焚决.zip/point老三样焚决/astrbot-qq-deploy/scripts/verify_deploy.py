#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""部署验收：配置项、人格、模型连通性、识图。

用法（在服务器上执行）：
    python verify_deploy.py                 # 只查配置与数据
    python verify_deploy.py --models        # 加测三个模型
    python verify_deploy.py --vision        # 加测识图
    python verify_deploy.py --data /opt/bots/astrbot/data

退出码：有 FAIL 时为 1。
"""
import argparse
import base64
import io
import json
import os
import sqlite3
import struct
import sys
import time
import urllib.request
import zlib

PASS, FAIL, SKIP = "PASS", "FAIL", "SKIP"
results = []


def add(ok, name, detail=""):
    results.append((ok, name, detail))
    print("  %-4s %s%s" % (ok, name, ("  ← " + detail) if detail else ""))


def load(path, default=None):
    try:
        return json.load(io.open(path, encoding="utf-8-sig"))
    except Exception:
        return default


def check_config(data):
    print("\n[配置]")
    cfg = load(os.path.join(data, "cmd_config.json"), {})
    if not cfg:
        add(FAIL, "读取 cmd_config.json")
        return cfg
    add(PASS, "读取 cmd_config.json")

    ar = (cfg.get("agent_runner") or {}).get("config") or {}
    persona = (ar.get("persona") or {}).get("persona_id")
    add(PASS if persona and persona != "default" else FAIL, "默认人格", str(persona))

    model = ((ar.get("model") or {}).get("provider_id") or "")
    add(PASS if model else FAIL, "对话主模型", model or "空")

    fb = (ar.get("model") or {}).get("fallback_provider_ids") or []
    add(PASS if fb else SKIP, "模型兜底", ",".join(fb) or "未设")

    turns = ((ar.get("compression") or {}).get("max_turns"))
    add(PASS if isinstance(turns, int) and turns > 0 else SKIP, "历史轮数上限", str(turns))

    ltm = cfg.get("provider_ltm_settings") or {}
    add(PASS if ltm.get("group_icl_enable") else FAIL, "群聊上下文 group_icl")
    add(PASS if ltm.get("group_message_history_enable") else FAIL, "群消息持久化")

    ps = cfg.get("platform_settings") or {}
    add(PASS if ps.get("empty_mention_waiting") is False else FAIL, "空@等待已关")
    seg = ((ps.get("segmented_reply") or {}).get("enable"))
    add(PASS if seg is False else SKIP, "平台分段已关", str(seg))

    admins = cfg.get("admins_id") or []
    add(PASS if admins else SKIP, "管理员", ",".join(map(str, admins)) or "未设")
    return cfg


def check_persona(data):
    print("\n[人格]")
    db = os.path.join(data, "data_v4.db")
    if not os.path.exists(db):
        add(FAIL, "data_v4.db 存在")
        return
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    rows = list(con.execute("select persona_id, length(system_prompt) from personas"))
    con.close()
    add(PASS, "人格表可读", "%d 条" % len(rows))
    for pid, n in rows:
        print("        - %s (%d 字)" % (pid, n))
    long_ok = any(n > 500 for _, n in rows)
    add(PASS if long_ok else FAIL, "存在实质人格（>500 字）")


def check_plugins_config(data):
    print("\n[插件配置]")
    base = os.path.join(data, "config")

    gcp = load(os.path.join(base, "astrbot_plugin_group_chat_plus_config.json"), {})
    add(PASS if gcp.get("decision_ai_provider_id") else FAIL,
        "读空气模型", str(gcp.get("decision_ai_provider_id")))
    add(PASS if gcp.get("image_to_text_provider_id") else SKIP,
        "识图模型", str(gcp.get("image_to_text_provider_id")))
    wl = gcp.get("plugin_gcp_reset_here_allowed_user_ids")
    add(PASS if wl else FAIL, "重置白名单已收紧", str(wl))

    lm = load(os.path.join(base, "astrbot_plugin_livingmemory_config.json"), {})
    prov = lm.get("provider_settings") or {}
    add(PASS if prov.get("embedding_provider_id") else FAIL,
        "记忆向量模型", str(prov.get("embedding_provider_id")))
    add(PASS if prov.get("llm_provider_id") else SKIP,
        "记忆 LLM", str(prov.get("llm_provider_id")))

    sl = load(os.path.join(base, "astrbot_plugin_self_learning_config.json"), {})
    mc = sl.get("Model_Configuration") or {}
    add(PASS if mc.get("filter_provider_id") else FAIL,
        "学习过滤模型", str(mc.get("filter_provider_id")))
    pe = sl.get("Persona_Evolution_Settings") or {}
    add(PASS if pe.get("enable_persona_evolution") is False else FAIL,
        "人格演化已关")

    sg = load(os.path.join(base, "astrbot_plugin_smart_segmentation_config.json"), {})
    if sg:
        add(PASS if sg.get("provider_id") else SKIP, "分段模型", str(sg.get("provider_id")))


def post(url, key, body, timeout=120):
    req = urllib.request.Request(
        url, data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + key})
    t0 = time.time()
    with urllib.request.urlopen(req, timeout=timeout) as r:
        j = json.loads(r.read().decode())
    return j, time.time() - t0


def check_models(cfg):
    print("\n[模型连通性]")
    srcs = {s.get("id"): s for s in cfg.get("provider_sources", []) if s.get("key")}
    for p in cfg.get("provider", []):
        if p.get("type") or p.get("provider_type"):
            continue
        pid = p.get("id", "")
        src = srcs.get(p.get("provider_source_id"))
        if not src:
            continue
        key = (src.get("key") or [""])[0]
        base = (src.get("api_base") or "").rstrip("/")
        body = {"model": p.get("model"),
                "messages": [{"role": "user", "content": "只回两个字：在的"}],
                "max_tokens": 30}
        body.update(p.get("custom_extra_body") or {})
        try:
            j, dt = post(base + "/chat/completions", key, body)
            txt = (j["choices"][0]["message"].get("content") or "").strip()[:12]
            add(PASS, pid, "%.1fs → %s" % (dt, txt))
        except Exception as e:
            add(FAIL, pid, repr(e)[:80])


def _png(w, h, rgb):
    raw = b"".join(b"\x00" + bytes(rgb) * w for _ in range(h))

    def chunk(t, d):
        c = t + d
        return struct.pack(">I", len(d)) + c + struct.pack(">I", zlib.crc32(c) & 0xffffffff)

    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))


def check_vision(cfg):
    print("\n[识图]")
    srcs = {s.get("id"): s for s in cfg.get("provider_sources", []) if s.get("key")}
    target = None
    for p in cfg.get("provider", []):
        if p.get("type") or p.get("provider_type"):
            continue
        if "image" in (p.get("modalities") or []):
            target = p
            break
    if not target:
        add(SKIP, "无可用于识图的 provider")
        return
    src = srcs.get(target.get("provider_source_id"))
    if not src:
        add(SKIP, "识图 provider 无密钥")
        return
    url = "data:image/png;base64," + base64.b64encode(_png(80, 80, (255, 140, 0))).decode()
    body = {"model": target.get("model"), "max_tokens": 40, "messages": [{"role": "user", "content": [
        {"type": "text", "text": "这张图是什么颜色？只回答颜色。"},
        {"type": "image_url", "image_url": {"url": url}}]}]}
    try:
        j, dt = post((src["api_base"]).rstrip("/") + "/chat/completions",
                     (src.get("key") or [""])[0], body, timeout=90)
        txt = (j["choices"][0]["message"].get("content") or "").strip()
        add(PASS if txt else FAIL, "识图 " + str(target.get("id")), "%.1fs → %s" % (dt, txt[:10]))
    except Exception as e:
        add(FAIL, "识图 " + str(target.get("id")), repr(e)[:80])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="/opt/bots/astrbot/data")
    ap.add_argument("--models", action="store_true")
    ap.add_argument("--vision", action="store_true")
    a = ap.parse_args()

    print("=" * 56)
    print("部署验收  data =", a.data)
    print("=" * 56)

    cfg = check_config(a.data)
    check_persona(a.data)
    check_plugins_config(a.data)
    if a.models and cfg:
        check_models(cfg)
    if a.vision and cfg:
        check_vision(cfg)

    fails = [r for r in results if r[0] == FAIL]
    print("\n%s" % ("=" * 56))
    print("通过 %d / 失败 %d / 跳过 %d"
          % (len([r for r in results if r[0] == PASS]),
             len(fails), len([r for r in results if r[0] == SKIP])))
    if fails:
        print("失败项：")
        for _, n, d in fails:
            print("  -", n, d)
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
