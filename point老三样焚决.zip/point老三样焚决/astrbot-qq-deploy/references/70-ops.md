# 运维

## 一、备份

**只需要备 `astrbot/data/`。** 镜像和容器都能重建，数据不能。

```bash
cd /opt/bots
tar czf backup-$(date +%Y%m%d-%H%M).tar.gz astrbot/data
```

要备份的三样：

| 文件 | 内容 |
|---|---|
| `data/data_v4.db` | 人格、会话、平台统计 |
| `data/cmd_config.json` | 全部核心配置 |
| `data/plugin_data/` | 好感度、记忆、学习数据 |

改配置前先 copy 一份 `.bak-<时间戳>`，出问题能秒回滚。

---

## 二、清理（三种力度）

用户说"清一下"时，先确认是哪一种。

### 1. 只清会话（最轻）

```bash
docker stop astrbot
python3 - <<'PY'
import sqlite3
c = sqlite3.connect("/opt/bots/astrbot/data/data_v4.db")
for t in ("conversations", "platform_message_history", "platform_sessions"):
    c.execute("delete from %s" % t)
c.commit(); c.execute("vacuum")
PY
rm -rf /opt/bots/astrbot/data/plugin_data/astrbot_plugin_group_chat_plus/chat_history
docker start astrbot
```

效果：她忘记"刚才聊了什么"，但记得人。

### 2. 清会话 + 记忆（中等）

在上面基础上，删 livingmemory 的库文件，让它重建：

```bash
LM=/opt/bots/astrbot/data/plugin_data/astrbot_plugin_livingmemory
rm -f $LM/*.db $LM/*.db-shm $LM/*.db-wal $LM/*.index $LM/decay_state.json
rm -rf $LM/backups
```

效果：不记得往事，但好感度和心情还在。

### 3. 连好感度一起清（最狠）

```bash
docker stop astrbot
python3 - <<'PY'
import sqlite3
c = sqlite3.connect("/opt/bots/astrbot/data/plugin_data/astrbot_plugin_self_learning/messages.db")
for t in ("user_affections", "bot_mood", "affection_interactions",
          "raw_messages", "filtered_messages", "bot_messages"):
    try:
        c.execute("delete from %s" % t)
    except Exception as e:
        print("skip", t, e)
c.commit()
PY
docker start astrbot
```

### 清理前必做

```bash
tar czf /opt/bots/backup-before-clean-$(date +%Y%m%d-%H%M).tar.gz \
  /opt/bots/astrbot/data
```

**删之前先备份，删之后报告 "清了多少条、保留了什么"**，不要只说"清好了"。

---

## 三、改人格的标准流程

1. 改源文件（人格 markdown）
2. 体检：`python scripts/persona_lint.py <文件>`
3. 写库（停容器）或 WebUI 直接改
4. `docker start astrbot`
5. 群里发 `/gcp_reset_here`（想立刻生效）
6. 验证：sha1 比对库内与源文件

**别用 `/reset`**，它清会话内容。

---

## 四、升级插件/镜像

升级前必读：

| 升级什么 | 会丢什么 | 怎么补 |
|---|---|---|
| group_chat_plus | @ 判定补丁 | `patch_plugins.py --at-fix` |
| self_learning | 心情三补丁 + 排行榜补丁 + `_conf_schema` 的自定义字段 | `patch_plugins.py --all` |
| 重建 astrbot 容器 | 容器内 pip 装的依赖 | 重装 `cachetools scikit-learn` |
| 换镜像版本 | 可能改表结构 | 先备份 `data_v4.db` |

升级后固定动作：

```bash
python scripts/patch_plugins.py --check     # 看哪些补丁丢了
python scripts/verify_deploy.py             # 重新验收
```

---

## 五、日常巡检（可选）

```bash
# 一天看一次
docker ps
docker logs --tail 100 astrbot | grep -cE "ERROR|Traceback"
docker stats --no-stream

# 一周看一次
du -sh /opt/bots/astrbot/data
ls -la /opt/bots/astrbot/data/plugin_data/*/ | head
```

磁盘涨得快一般是日志或 `affection_interactions`（如果开了每日上限）。

---

## 六、把 bot 停下来

```bash
docker stop astrbot      # bot 离线，QQ 仍登录（NapCat 还活着）
docker stop napcat       # 连 QQ 一起下线
```

只停 astrbot 时，QQ 登录态保留，下次 `start` 秒连；
停 napcat 再启动可能要重新扫码（登录态通常还在，看情况）。

---

## 七、交接清单

把项目交给别人时给这五样：

1. 服务器地址与登录方式
2. `/opt/bots/README.md`（部署说明，含所有改动）
3. 最新的备份包路径
4. 打过的补丁清单（升级会覆盖）
5. 人格源文件路径（库里的可能被学习插件动过）

---

## 八、手动调好感度 / 心情

### 改某个人的好感度

先停容器，再改库：

```sql
-- 已有记录
UPDATE user_affections
SET affection_level = 60, updated_at = strftime('%s','now')
WHERE group_id = '<群号>' AND user_id = '<QQ号>';

-- 没有记录就插一条
INSERT INTO user_affections
  (group_id, user_id, affection_level, max_affection, created_at, updated_at)
VALUES ('<群号>', '<QQ号>', 60, 100, strftime('%s','now'), strftime('%s','now'));
```

库里在 `plugin_data/astrbot_plugin_self_learning/messages.db`。
改完重启，注入侧有 5 分钟缓存，等一会儿或重启都行。

**注意**：好感度下限被钳在 0，写负数也会被夹回 0（读取时不影响，但加分会立刻归零化）。

### 改当前心情

最省事的办法是**删掉当前心情**，下一条消息会自动生成新的：

```sql
DELETE FROM bot_mood WHERE group_id = '<群号>';
```

想指定情绪就用管理员命令：

```
/set_mood          # 插件自带，会走增量人格更新那条链路
```

或者直接插一条（`mood_type` 取 happy/sad/excited/calm/angry/anxious/playful/serious/nostalgic/curious）：

```sql
INSERT INTO bot_mood
  (group_id, mood_type, mood_intensity, mood_description, timestamp, start_time, end_time, is_active)
VALUES ('<群号>', 'playful', 0.6, '想逗人玩', strftime('%s','now'), strftime('%s','now'),
        strftime('%s','now') + 7200, 1);
```

### 改完怎么确认

```bash
# 好感度分布
sqlite3 messages.db "select user_id, affection_level from user_affections where group_id='<群号>' order by 2 desc;"
# 当前心情
sqlite3 messages.db "select mood_type, mood_intensity, is_active from bot_mood where group_id='<群号>' and is_active=1;"
```

别忘了：人格里如果没有【亲近程度】【此刻的心情】两段，改多少数据都不会改变说话方式。
