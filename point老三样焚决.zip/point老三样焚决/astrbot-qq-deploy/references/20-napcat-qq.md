# NapCat 与 QQ 登录

## 一、它是什么

NapCat 把 QQ 协议包装成 OneBot v11。AstrBot 通过反向 WebSocket 连它，
就像接了一个"QQ 平台适配器"。QQ 登录态存在 `./napcat/qq`，删了要重新扫码。

---

## 二、首次登录

```bash
docker restart napcat && sleep 16
docker exec napcat ls -l /app/napcat/cache/qrcode.png
docker exec napcat base64 -w0 /app/napcat/cache/qrcode.png | base64 -d > /tmp/qr.png
```

把 `/tmp/qr.png` 给用户扫。**二维码有效期约 2 分钟**，过期要重新出。

也可以用 NapCat 自带的 WebUI（6099 端口）登录，但二维码方式最稳。

登录成功的标志：日志里出现账号昵称，例如

```
10-21 20:14:11 [info] <昵称> | 接收 <- 群聊 [群名(群号)] [某人(QQ)] 内容
```

**把昵称记下来。** 人格的【人称与身份】段必须写：
"你的 QQ 昵称是「昵称」，记录里以它开头的行是你说的。"
不写这句，模型分不清自己说过什么。

---

## 三、OneBot 反向连接

配置文件：`/app/napcat/config/onebot11.json`

```json
{
  "network": {
    "httpServers": [],
    "httpSseServers": [],
    "httpClients": [],
    "websocketServers": [],
    "websocketClients": [
      {
        "enable": true,
        "name": "rws",
        "url": "ws://astrbot:6199/ws",
        "reportSelfMessage": false,
        "messagePostFormat": "array",
        "token": "",
        "heartInterval": 30000,
        "reconnectInterval": 30000
      }
    ]
  }
}
```

要点：

- `url` 用**容器名**，不要用 `127.0.0.1` 或宿主机 IP
- `messagePostFormat` 用 `array`，AstrBot 才能拿到结构化消息（图文分开）
- AstrBot 侧对应 `platform` 里 `aiocqhttp` 的 `ws_reverse_host 0.0.0.0` / `ws_reverse_port 6199`
- 两侧 token 必须一致（都用空最省事）

---

## 四、怎么判断"真的连上了"

**这是最容易误判的一步。**

### 假信号

`[Core] aiocqhttp(OneBot v11) 适配器已连接` —— 这只表示**AstrBot 侧适配器启动了**，
不代表 NapCat 已经连上来。

### 真信号 1：容器内看 TCP

两个容器在同一个 bridge 网络里通信，**宿主机 `ss` 看不到这条连接**。

```bash
docker exec napcat sh -c 'grep ":1837" /proc/net/tcp'
```

`1837` 是 6199 的十六进制。有输出且状态是 `01`（ESTABLISHED）才算通。

### 真信号 2：看 AstrBot 是否收到事件

最硬的判据是**数据落库**。装好 self_learning 后：

```bash
docker exec astrbot python -c "
import sqlite3,time
c=sqlite3.connect('/AstrBot/data/plugin_data/astrbot_plugin_self_learning/messages.db')
print(c.execute('select count(*) from raw_messages').fetchone())
"
```

群里发一条消息，数字变大 = 事件通了。

### 真信号 3：NapCat 侧日志

```bash
docker logs --tail 50 napcat | grep -avE '^[0-9a-f]{64}$'
```

出现 `接收 <- 群聊 [...]` 说明 QQ 侧在线；
出现 `反向WebSocket ... 连接意外关闭` 说明连 AstrBot 失败。

---

## 五、常见故障

| 现象 | 原因 | 处理 |
|---|---|---|
| 二维码刷不出来 | 容器还在初始化 | 等 15-20 秒再取 |
| 扫码后无反应 | 二维码过期 | 重新 restart 出码 |
| 反复 `连接意外关闭` | astrbot 容器没起 / 端口不对 | 先看 astrbot 是否 running |
| 收到消息但 bot 不回 | 见排障文档（大概率是 @ 判定或概率） |
| 掉线后不自动恢复 | 登录态失效 | 重新扫码 |
