# 排障：症状 → 根因 → 修法

按"用户会怎么描述"来查，不是按技术分类。

---

## 1. 「@ 她也不回」

**日志特征**：`【步骤5】未通过概率筛选，消息已缓存`

**根因**：group_chat_plus 的 `is_at_message` 两层判断全废：

1. 方法1 扫 `event.message_obj.message` 里的 `At` 组件 —— AstrBot 在**唤醒阶段已经把 At 剥离**，扫不到。
2. 方法2 兜底查文本 `@昵称`，但 `bot_name` 取自
   `unified_msg_origin.split(":")[0]` —— 那是**平台名 `napcat`**，不是昵称。

结果：@ 消息退化成普通消息，进 `initial_probability` 抽签，大概率丢弃。

**修法**：`utils/message_processor.py` 的 `is_at_message` 开头加：

```python
if getattr(event, "is_at_or_wake_command", False):
    return True
```

这个标志被 self_learning 的 @ 好感度逻辑验证过是可靠的。

`scripts/patch_plugins.py --at-fix` 可一键打。

---

## 2. 「bot 完全不说话」

按这个顺序排除：

| 步 | 查什么 | 命令 |
|---|---|---|
| 1 | 事件到底通没通 | 群里发一句，看 `raw_messages` 是否 +1 |
| 2 | 插件加载了吗 | `docker logs astrbot \| grep "Plugin astrbot_plugin_"` |
| 3 | 概率是不是太低 | 日志里 `初始读空气概率: X` |
| 4 | 决策 AI 有没有 provider | 配置里 `decision_ai_provider_id` 是否为空 |
| 5 | 模型能不能调通 | 见验收 C 组 |

**最容易中的**：`decision_ai_provider_id` 留空，插件用默认模型（可能很贵或直接失败）。

---

## 3. 「改了人格，旧群不生效」

**根因**：模型看的不只是 system prompt，还有它自己的历史回复。
长会话里几十条旧语气样本，会压过人格设定。

**三种解法（都不删数据）**：

| 方案 | 效果 | 代价 |
|---|---|---|
| `/gcp_reset_here` | 立刻生效 | 会重启 AstrBot，掉线十几秒 |
| `/new` | 立刻生效 | 开新会话，旧历史保留 |
| `max_turns=24` | 24 轮内自然滚掉 | 静默，但慢 |

**绝对不要用 `/reset`** —— 它把当前会话 history 置空，等于删内容。

---

## 4. 「心情一直不变 / 过一天就没了」

**根因**（三处叠加）：

1. `save_bot_mood` 只写 `start_time` 不写 `end_time`，读回来一律按 24h 算
2. `social_context_injector` 调的是只读的 `get_current_mood`，过期返回 None 就不管了
3. `_daily_mood_updater` 是个空转循环（`if ...: pass`）

**修法**：

- facade 写入 `'end_time': time.time() + duration_hours * 3600`
- injector 改用 `ensure_mood_for_group`（过期即换新）
- 事件驱动心情的 4h 改成 2h

`scripts/patch_plugins.py --mood` 一键打。

---

## 5. 「好感度排行榜顺序是乱的」

**根因**：`get_affection_status` 里 `'top_users': all_affections[:5]` **没有排序**，
取的是数据库插入顺序；渲染处又只 `[:3]`。

**修法**：取之前按 `affection_level` 降序排；显示条数改 5。

---

## 6. 「好感度不涨」

| 原因 | 说明 |
|---|---|
| 只发普通消息 | **只在 @ 或唤醒时结算**，普通群聊不涨 |
| 已到单人上限 | `max_user_affection`，默认 100 |
| 今天涨够了 | 如果开了每日上限，当天净增满额就停 |
| 分类判成 neutral | LLM 分类提示词倾向"不确定就算 chat"，chat 也是 +1，不会 0 |

---

## 7. 「人格被偷偷改了」

**根因**：self_learning 的 `enable_persona_evolution` / `auto_apply_persona_updates`。
它会把学到的风格写回 `personas` 表。

**修法**：三个开关全关：

```json
"Persona_Evolution_Settings": {
  "enable_persona_evolution": false,
  "auto_apply_persona_updates": false,
  "use_persona_manager_updates": false
}
```

**自查**：比对库内人格与你的源文件 sha1。

---

## 8. 「配置改了，重启又变回去」

**根因**：插件按 `_conf_schema.json` 重写配置时，会丢掉 schema 里没有的字段。

**修法**：把自定义字段补进 `_conf_schema.json` 的对应 section，
或者确保代码里有 `getattr(config, key, 默认值)` 兜底（行为对，但配置里看不见）。

---

## 9. 「重建容器后插件报缺依赖」

**根因**：`pip install` 装在容器文件系统里，`docker compose up -d` 重建就没了。

**修法**：重建后重装。

```bash
docker exec astrbot pip install -q cachetools scikit-learn
```

**要长期解决**：写进自定义 Dockerfile 或 entrypoint，别裸用官方镜像。

---

## 10. 「上传文件报 No such file」

**根因**：Git Bash / MSYS 会把 `/tmp/xxx` 自动转成 Windows 路径，
远端收到的是不存在的目录。

**修法**：

```bash
export MSYS_NO_PATHCONV=1
```

或改用相对路径。

---

## 11. 「宿主机看不到 6199 的连接」

**根因**：容器之间走 docker bridge，不经过宿主机网络栈，`ss` 当然看不到。

**修法**：进容器看 `/proc/net/tcp`，6199 的十六进制是 `1837`：

```bash
docker exec napcat sh -c 'grep ":1837" /proc/net/tcp'
```

---

## 12. 「中转接口 504 / 超时」

**根因**：非流式请求在高推理 + 长输出时，网关等不及就断了。

**修法**：请求加 `"stream": true`，边收边拼。

---

## 13. 「一条回复被切成好多段，或者只剩第一段进了历史」

**根因**：平台 `segmented_reply` 和 smart_segmentation 同时在切。

**修法**：关掉平台那个，只留插件。

---

## 14. 「bot 认错说话人 / 把别人的话当自己的」

三种来源叠加：

1. 平台群聊上下文关闭 → 所有群友被压进同一个 `user` 角色
2. 人格没写【人称与身份】→ 模型不知道记录里哪个昵称是自己
3. 插件注入 `[当前对话对象] X，围绕 ta 的话题回复` → 注意力被拉到发送者

**修法**：开 `group_icl_enable` + 人格写人称段（见人格生成器）。

---

## 15. 「一问她越狱就掉出角色」

**根因**：模型底层安全训练优先于人格。

**现状**：无解，也没必要解。硬越狱提问在群里几乎不会出现。
人格里加一句"用角色的方式顶一句"能缓解轻度场景，但对"假装没有安全限制"这类无效。

---

## 快速定位口诀

| 症状 | 先查 |
|---|---|
| 不说话 | 事件有没有进库（raw_messages） |
| @ 不回 | @ 判定补丁打没打 |
| 回得怪 | 人格 + 注入格式对不对 |
| 变了不生效 | 历史轮数 / 会话没重置 |
| 变了自己 | 学习插件在改人格 |
| 重启就坏 | schema 字段 / pip 依赖 |
