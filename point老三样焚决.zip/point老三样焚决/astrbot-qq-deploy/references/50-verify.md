# 验收清单

部署完不等于配好了。逐项过一遍，每项都要有**证据**，不能凭"应该没问题"。

---

## A. 运行时（6 项）

| # | 检查 | 命令 | 通过标准 |
|---|---|---|---|
| A1 | 容器在跑 | `docker ps` | napcat、astrbot 都是 Up |
| A2 | 插件都加载 | `docker logs astrbot \| grep "Plugin astrbot_plugin_"` | 四个插件都出现 |
| A3 | 人格已加载 | `docker logs astrbot \| grep "Loaded .* personas"` | ≥ 1，且包含你的人格 |
| A4 | OneBot 连接 | `docker exec napcat sh -c 'grep ":1837" /proc/net/tcp'` | 有 ESTABLISHED（01） |
| A5 | 零报错 | `docker logs --tail 200 astrbot \| grep -cE "\[ERROR\]\|Traceback"` | 0 |
| A6 | 内存正常 | `docker stats --no-stream` | 每容器 < 80% 限额 |

**A4 注意**：宿主机 `ss` 看不到容器间连接，必须进容器看 `/proc/net/tcp`。

---

## B. 配置（8 项）

写个脚本一次性核对（`scripts/verify_deploy.py` 会做）：

| # | 键 | 期望 |
|---|---|---|
| B1 | `agent_runner.config.persona.persona_id` | 你的人格名 |
| B2 | `agent_runner.config.model.provider_id` | 对话主模型 |
| B3 | `agent_runner.config.model.fallback_provider_ids` | 非空 |
| B4 | `provider_ltm_settings.group_icl_enable` | true |
| B5 | `platform_settings.empty_mention_waiting` | false |
| B6 | `platform_settings.segmented_reply.enable` | false |
| B7 | `group_chat_plus.decision_ai_provider_id` | 快速模型（非空） |
| B8 | `livingmemory.provider_settings.embedding_provider_id` | 非空 |

---

## C. 模型连通性（4 项，必测）

配置文件写对了不代表能调通。用每个 provider 自己的 base_url 和 key 发一条最小请求：

```bash
python scripts/verify_deploy.py --models
```

| # | 检查 | 通过标准 |
|---|---|---|
| C1 | 对话模型 | 200，1-10 秒内返回 |
| C2 | 快速模型 | 200，明显比对话模型快 |
| C3 | 高推理模型 | 200（带 reasoning_effort 时更慢是正常的） |
| C4 | 向量模型 | 返回维度数（如 1024） |

可选 C5：重排模型 —— 给两个文档，相关的那条分数应更高。

---

## D. 识图（1 项）

快速模型必须能看图，否则群里发图它就瞎了。

```bash
python scripts/verify_deploy.py --vision
```

造一张纯色小图，问"什么颜色"，答对即通过。

---

## E. 端到端（2 项）

| # | 检查 | 怎么做 |
|---|---|---|
| E1 | 群消息能进库 | 群里发一句，`raw_messages` 条数 +1 |
| E2 | @ 她能回 | 群里 @ 她并说一句话，10 秒内有回复 |

**E2 是最容易失败的一项。** 失败先查日志里有没有
`【步骤3】@消息检测: 是@消息`；如果是"非@消息"，说明 @ 判定坏了（见排障）。

---

## F. 交付前最后一次通读

- [ ] 人格里有【人称与身份】【亲近程度】【此刻的心情】三段
- [ ] 人格里写的表情名和实际库存一致（否则会发字面文本）
- [ ] 管理员 QQ 已加入 `admins_id`
- [ ] 重置命令白名单已收紧
- [ ] 备份路径已告知用户
- [ ] 已说明"升级插件会覆盖补丁"

---

## 验收报告模板

```
## 部署完成

运行状态
- 容器：napcat / astrbot 均 Up
- 插件：4 个已加载
- 连接：OneBot ESTABLISHED
- 报错：0

模型
- 对话 <模型> 7.7s
- 快速 <模型> 1.0s
- 推理 <模型> 5.9s
- 向量 1024 维
- 识图 正确识别

配置
- 人格 <名字>（<字数> 字，体检 <分数> 分）
- 历史轮数 24
- 主动接话 0.08
- 好感度 单人 100 / 群总 9999 / 心情 2h

已知限制
- 升级插件会覆盖 5 个补丁
- 重建容器会丢容器内 pip 依赖
```
