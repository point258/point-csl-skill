# 服务器与容器

## 一、最低要求

| 项 | 要求 | 说明 |
|---|---|---|
| 系统 | 任意 Linux（Ubuntu 22.04 / Debian 12 最省事） | 需要能装 Docker |
| 内存 | ≥ 1 GB | 1GB 机器必须开 swap，否则 AstrBot 启动时会被 OOM |
| 磁盘 | ≥ 10 GB | 镜像约 2 GB，加上数据库和日志 |
| Docker | ≥ 24，含 compose v2 | `docker compose` 而非 `docker-compose` |
| 出网 | 能访问 Docker Hub 或镜像加速 | 国内机器建议配加速器 |

**开 swap（1GB 机器必做）**：

```bash
fallocate -l 2G /swapfile && chmod 600 /swapfile
mkswap /swapfile && swapon /swapfile
echo '/swapfile none swap sw 0 0' >> /etc/fstab
```

---

## 二、目录结构

```
/opt/bots/
├── docker-compose.yml
├── napcat/
│   ├── config/          # onebot11.json 等
│   └── qq/              # QQ 登录态（别删，删了要重新扫码）
└── astrbot/
    └── data/
        ├── cmd_config.json        # 核心配置
        ├── data_v4.db             # 会话 / 人格 / 统计（SQLite）
        ├── config/                # 各插件配置 JSON
        └── plugin_data/           # 各插件数据
```

**只有 `data/` 需要备份。** 镜像和容器都可以重建。

---

## 三、编排模板

见 `assets/docker-compose.yml.tpl`。要点：

- 两个服务在同一个 bridge 网络，NapCat 用 `ws://astrbot:6199/ws` 直连，不经过宿主机
- `TZ` 必须设，否则时间相关的功能（心情周期、每日上限）会错
- `restart: unless-stopped`，服务器重启后自动拉起
- 端口映射按需：6185 面板、6199 反向 WS、6099 NapCat 面板、7833 可选插件面板

```yaml
services:
  napcat:
    image: mlikiowa/napcat-docker:latest
    container_name: napcat
    restart: unless-stopped
    environment:
      NAPCAT_UID: "0"
      NAPCAT_GID: "0"
      MODE: "astrbot"
      TZ: "Asia/Shanghai"
    ports:
      - "6099:6099"
    volumes:
      - ./napcat/config:/app/napcat/config
      - ./napcat/qq:/app/.config/QQ
    networks: [botnet]

  astrbot:
    image: soulter/astrbot:latest
    container_name: astrbot
    restart: unless-stopped
    environment:
      TZ: "Asia/Shanghai"
    ports:
      - "6185:6185"
      - "6199:6199"
    volumes:
      - ./astrbot/data:/AstrBot/data
    networks: [botnet]

networks:
  botnet:
    driver: bridge
```

---

## 四、端口与安全组

| 端口 | 用途 | 是否必须公网 |
|---|---|---|
| 6185 | AstrBot WebUI | 建议只放行自己 IP |
| 6199 | OneBot 反向 WS | **不要放公网**，只走容器内网 |
| 6099 | NapCat 面板 | 建议只放行自己 IP |
| 7833 | 插件面板（可选） | 只放行自己 IP |

**6199 绝对不要对公网开放。** 它没有认证，任何能连上的人都能冒充 QQ 事件。

安全组最小开放：22（SSH）+ 6185（限自己 IP）。

---

## 五、初始化

```bash
mkdir -p /opt/bots && cd /opt/bots
# 写入 compose 后
docker compose up -d
docker compose ps
docker compose logs --tail 50 astrbot
```

首次启动 AstrBot 会生成 `data/` 与默认配置，WebUI 账号 `astrbot`，
密码在 `docker logs astrbot` 里打印一次，**首次登录会要求改密**。记下来交给用户。

---

## 六、常见环境问题

| 现象 | 原因 | 处理 |
|---|---|---|
| `docker compose` 不存在 | 装的是 v1 | 装 compose v2 插件 |
| 拉镜像超时 | 国内网络 | 配 registry-mirrors |
| AstrBot 反复重启 | 内存不足（OOM） | 开 swap，或换 2G 机器 |
| 容器内 `pip install` 后重启丢失 | 没挂载 site-packages | 见"运维"一节的重建注意 |
