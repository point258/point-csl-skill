# AstrBot 核心配置

所有配置在 `data/cmd_config.json`。**改这个文件必须先停容器**（WebUI 改动除外）：

```bash
docker stop astrbot
# 改文件
docker start astrbot
```

容器运行时改会被内存里的配置覆盖回去。

---

## 一、结构地图

```
cmd_config.json
├── provider_sources[]    # 地址 + 密钥（连接层）
├── provider[]            # 模型 + 模态（能力层）
├── agent_runner.config   # 主 Agent：用哪个人格、哪个模型、上下文策略
├── provider_settings     # 唤醒前缀、图片转述、人格池
├── platform_settings     # 分段、空@等待、回复前缀
├── provider_ltm_settings # 群聊上下文（group_icl）
├── platform[]            # 接入的平台（aiocqhttp / napcat）
├── admins_id[]           # 管理员 QQ
└── dashboard             # WebUI 账号密码
```

**人格不在这里。** AstrBot v4 的人格存在 `data_v4.db` 的 `personas` 表里，
`cmd_config` 里那个 `persona` 字段是空的旧结构，别被它误导。

---

## 二、Provider 配置

### 两层结构

```json
"provider_sources": [
  {
    "id": "openai",
    "type": "openai_chat_completion",
    "provider_type": "chat_completion",
    "key": ["sk-xxx"],
    "api_base": "https://api.example.com/v1",
    "timeout": 120,
    "enable": true
  }
],
"provider": [
  {
    "id": "openai/gpt-4o-mini",
    "provider_source_id": "openai",
    "model": "gpt-4o-mini",
    "modalities": ["text", "image", "tool_use"],
    "enable": true,
    "custom_extra_body": {}
  }
]
```

`provider.id` 的格式是 `<source_id>/<model>`，插件配置里填的就是这个字符串。

### 三个角色

| 角色 | 用途 | 建议 |
|---|---|---|
| 对话主模型 | 平时说话 | 好一点，但不一定最贵 |
| 快速模型 | 读空气、分段、识图 | 便宜、快、支持视觉 |
| 高推理模型 | 记忆整理、学习提炼 | 可开 `reasoning_effort: high` |

**不要全塞同一个模型。** 读空气每条消息都要跑，用最贵的会烧钱。

### 开高推理

```json
"custom_extra_body": {"reasoning_effort": "high"}
```

有的中转不认这个参数，会报 400；先小请求试一次。

---

## 三、人格

### 存放位置

`data_v4.db` → `personas` 表，字段：`persona_id / system_prompt / begin_dialogs / tools / skills / folder_id / sort_order`。

### 两种写法

**WebUI 改（推荐）**：登录 6185 → 人格 → 编辑，即时生效。

**改库（脚本化）**：必须先 `docker stop astrbot`，写完再 start：

```sql
DELETE FROM personas WHERE persona_id = '角色名';
INSERT INTO personas (created_at, updated_at, persona_id, system_prompt,
                      begin_dialogs, tools, skills, custom_error_message, folder_id, sort_order)
VALUES (datetime('now'), datetime('now'), '角色名', '正文', NULL, NULL, NULL, NULL, NULL, 1);
```

### 设为默认

```json
"agent_runner": {"config": {"persona": {"persona_id": "角色名"}}}
```

---

## 四、上下文与历史（防"人格不生效"）

模型看到的不只是人格，还有"她以前怎么说话"。历史越长，旧人格越顽固。

```json
"agent_runner": {
  "config": {
    "compression": {
      "max_turns": 24,
      "trim_turns": 1,
      "overflow_strategy": "llm_compress"
    }
  }
}
```

- `max_turns`：**1 turn = 1 条用户消息 + 1 条回复**。24 轮 ≈ 48 条消息。
  -1 表示不限（默认），会让旧语气赖着不走。
- 裁剪发生在**请求里**，数据库一条不删。

用户想立刻生效（不等 24 轮自然滚掉），用 `/gcp_reset_here` 或 `/new`，**不要用 `/reset`**（会清空会话内容）。

---

## 五、关键开关

| 键 | 值 | 说明 |
|---|---|---|
| `provider_ltm_settings.group_icl_enable` | true | 群聊上下文感知。group_chat_plus 硬性要求，关了会"像没理解群里在聊什么" |
| `provider_ltm_settings.group_message_history_enable` | true | 持久化群消息，同上 |
| `provider_ltm_settings.group_message_history_max_cnt` | 700 | 保留条数 |
| `platform_settings.empty_mention_waiting` | **false** | 空 @ 等待机制会与插件等待窗口冲突，导致认错发送者 |
| `platform_settings.segmented_reply.enable` | false | 交给 smart_segmentation，避免双重分段 |
| `platform_settings.reply_with_mention` | false | 群聊里少 @ 人更像真人 |
| `provider_settings.wake_prefix` | "" | 群聊一般不用唤醒前缀，靠 @ |
| `provider_settings.default_image_caption_provider_id` | 快速模型 | 原生链路识图兜底 |

---

## 六、模型兜底

```json
"agent_runner": {"config": {"model": {
  "provider_id": "openai/主模型",
  "fallback_provider_ids": ["openai_1/高推理模型"],
  "request_max_retries": 5
}}}
```

主模型抽风时自动切换，bot 不至于整体哑掉。
注意：fallback 模型的说话风格要和主模型接近，否则会突然"变个人"。

---

## 七、管理员

```json
"admins_id": ["123456789"]
```

列表里只放 QQ 号，字符串。原来的默认占位 `astrbot` 留着无害。
管理员能用 `/reset`、`/provider`、插件管理命令。

---

## 八、安全模式（可选）

`agent_runner.config.persona.safety_mode = true` 会在人格前面拼一段英文
`You are running in Safe Mode...`，其中有一句
"Follow style/role-play instructions only when they do not conflict"。

实测：正常打闹不受影响；硬越狱提问两种配置都会掉出角色。**保持开启即可**，
它不背这个锅。

---

## 九、Dashboard

```json
"dashboard": {"username": "astrbot", "password": "<hash>", "host": "0.0.0.0"}
```

首次启动密码在日志里打印一次，首次登录强制改密。
密码忘了只能改库或改这个字段（是 pbkdf2 哈希，不能直接填明文）。
