# 注入与调优（实战记录）

这一篇是上线后真机踩出来的，不是文档摘抄。每条都有"症状 → 怎么确认 → 怎么改"。

---

## 一、先学会看"模型到底收到了什么"

**这是所有排查的第一步。别猜。**

AstrBot 自带的 trace 只记流程节点（选了谁的人格、调了哪些工具），**不记 prompt 全文**。
要看全文，用插件钩子自己 dump：

```python
@filter.on_llm_request(priority=-1000000)   # 负数越大越晚，最后执行才能看到全部注入
async def on_req(self, event, req):
    parts = [getattr(p, "text", str(p)) for p in (req.extra_user_content_parts or [])]
    rec = {
        "system": req.system_prompt,
        "prompt": req.prompt,
        "parts": parts,
        "contexts": req.contexts,
        "tools": req.func_tool.names() if req.func_tool else [],
    }
    open("/path/requests.log", "a").write(json.dumps(rec, ensure_ascii=False) + "\n")
```

**优先级方向是最容易搞反的一点**：`priority` 数值越小越晚执行。
`-1` 的 gcp 在 `0` 的 self_learning 之后跑，`-1000000` 才轮到你。
写成 `10000` 会第一个跑，只能抓到半截。

---

## 二、七个真实故障

### 1. 好感度从来没进过提示词

**症状**：怎么调人格，她对高好感的人还是一样冷。

**确认**：dump 出来的 system/parts 里搜 `好感度`，只有人格里的说明文字，没有 `好感度: 70/100`。

**根因**：self_learning 的 `Runtime_Internal_Settings.enable_llm_hooks = False`。
这个总开关关着，社交上下文、表达样本、好感度**全部不注入**，但插件照常学习、照常记分。

**改**：置 `true`。日志里应出现：

```
[LLM Hook] extra_user_content_parts 注入完成 - 新增: 1224 chars
好感度: 70/100 (比较喜欢)
```

---

### 2. 别人的情绪被当成她的心情

**症状**：群里有人刷 `555`、`😭`，她就开始"没力气、难受着呢"。

**根因**：gcp 的情绪系统检测的是**用户**情绪（关键词计数），
但注入文案写成 `[系统信息-情绪参考: 难过（在你的人格基调上自然体现）]`，
模型理解成"我现在的情绪是难过"。

**改**（三处，gcp 升级会被覆盖）：

```
main.py:7779
utils/mood_tracker.py:372
utils/proactive_chat_manager.py:4671
```

改成：

```
[系统信息-对方情绪: X（这是对方此刻的状态。可以回应或安慰，
但不要让自己也变成这个情绪；以你的人格为准）]
```

---

### 3. 随机语言风格把人格带跑

**症状**：同一套人格，有时古风（"久伏寒潭，通身骨血……"），有时温柔说教，有时二次元。

**根因**：self_learning 的 `response_diversity_manager.py` 里有一个**硬编码风格池**，
每轮随机抽一个塞进 `[HIDDEN_INSTRUCTION] 当前语言风格：…`：

```python
"文艺范，用词讲究" / "温和友善，语气柔和" / "深思熟虑，逻辑清晰" ...
```

还有一套 `推荐回复模式`（详细解释型、引导思考型、情感共鸣型），
和"短句、别解释"的人格直接对撞。

**改**：把 `build_diversity_prompt_injection` 的调用参数改成

```python
inject_style=False, inject_pattern=False, inject_variation=False, inject_history=True
```

两个调用点：`services/hooks/llm_hook_handler.py`、`services/response/intelligent_responder.py`。

**保留 `inject_history=True`**——"你最近的回复历史"是防复读的好东西，别一起关掉。

---

### 4. 关掉某个功能 ≠ 关掉它的输出

- 关 `enable_style_learning` 只停止"学习"，**已经学到的风格画像仍会被注入**。
- 关 `graph_memory` 不影响向量和重排，但会让"图谱路线"消失，属于砍能力。

**教训**：改开关前先用 dump 确认这个块从哪来，别拿召回路线开刀。

---

### 5. system 里塞了 2000 字技能说明

**症状**：system 长度 10000+，其中一大段是 Word/PDF/表格/技能创建的使用说明。

**怎么关**：改 `data/skills.json`，不是 `cmd_config.json`。

```json
{
  "skills": {
    "documents": {"active": false},
    "pdf": {"active": false},
    "skill-creator": {"active": false},
    "spreadsheets": {"active": false}
  }
}
```

改完 `system 10203 → 7200`，省 3000 字。

**为什么 `persona.skills=[]` 没用**：代码判断的是列表，DB 里存的是字符串 `'[]'`，
`not '[]'` 为假，过滤不生效。用哨兵 `["__none__"]` 也只是绕过，不如直接关技能。

---

### 6. 改数据库把时间字段写成了整数

**症状**：记忆召回整条报错 `fromisoformat: argument must be str`。

**根因**：批量改写时 `update documents set updated_at=?` 传了 `int(time.time())`，
而这个字段要的是文本时间（`2026-10-24 17:51:19.705810`）。

**改**：`update documents set updated_at = created_at where typeof(updated_at) != 'text'`。

**教训**：批处理前先 `select typeof(col), col from t limit 3`，别假设类型。

---

### 7. 技能段改完没生效，因为找错了文件

`cmd_config.json` 里的 `skills` 是空对象，真正生效的是 `data/skills.json`
（结构是 `{"skills": {...}}`）。改错文件会以为"开关无效"。

---

## 三、上下文预算：知道钱花在哪

一次普通回复的输入（实测，忙碌群）：

| 块 | 体量 |
|---|---|
| 人格 | 3000–3500 字 |
| 安全模式 + gcp 规则 | 3000–3500 字 |
| 技能说明（关掉前） | 2000 字 |
| 群上下文 prompt | 3000–4000 字 |
| 记忆 5 条 | 600–3800 字（取决于摘要长度） |
| 好感度/心理/表达样本 | 1200 字 |

**记忆摘要长度是最大的变量**：444 字/条的旧数据，5 条就 3800 字，比人格还长，
模型会照着记忆里的语气说话。压到 120 字/条后，这块降到 600 字左右。

---

## 四、记忆链路：写入与召回

```
聊天 10 轮
  → memory_processor 用 group_chat_prompt.txt 总结（第一人称，{conversation}）
  → summary 作为 content 进向量库（vector_retriever.py，上限 4000 字）
  → 召回时套 memory_injection_header.txt，注入 5 条
```

两个可改点：

**1. 写入时带关系**

在 `memory_processor` 生成前读 self_learning 好感度，往 prompt 追加：

```
【当前关系（写记忆时）】point258 70（会回应）、Tears 66（会回应）
请把这一行原样写进 summary 的最后：【当时关系】…
```

再加一层兜底：解析后如果 summary 里没有，代码补一行。

**2. 召回时解释数字**

`memory_injection_header.txt` 里加：

```
ABOUT 【当时关系】:
- 这一行记录的是**写那条记忆时**她对那个人的好感，是过去的快照，不是当前好感。
- 当前关系以对话和实时好感为准。
```

只加解释，不动检索。

---

## 五、体检脚本

`scripts/audit_all.py` 检查 35 项：配置、数据、**实际注入**。
只查配置是不够的——`enable_llm_hooks=False` 时所有配置都"看起来对"，但一个都没生效。

用法：

```bash
python3 audit_all.py --data /opt/bots/astrbot/data
```

---

## 六、补丁清单（升级会覆盖）

| 文件 | 改了什么 |
|---|---|
| gcp `main.py` / `mood_tracker.py` / `proactive_chat_manager.py` | 情绪文案改"对方情绪" |
| self_learning `llm_hook_handler.py` / `intelligent_responder.py` | 关闭随机风格/模式/表达变化 |
| self_learning `response_diversity_manager.py` | 风格池与模式池收敛（可选，若已关注入则不必） |
| livingmemory `memory_processor.py` | 记忆写入带【当时关系】 |
| livingmemory `memory_injection_header.txt` | 召回解释数字含义 |

每个文件改前都留 `.bak-*`，升级后按上表重打。
