# 四个插件

安装方式：WebUI 插件市场搜索，或把 zip 丢进 `data/plugins/` 后重启。
装完必须**逐个填 provider 槽位**——留空不会报错，它会默默用最贵的那个模型。

---

## 一、group_chat_plus（读空气）

**作用**：决定"这条消息要不要接"。带概率、带上下文理解、带多气泡。

### 必填

| 键 | 填什么 |
|---|---|
| `decision_ai_provider_id` | 快速模型（每条群消息都可能调用） |
| `image_to_text_provider_id` | 快速模型（需支持视觉） |
| `enable_image_processing` | true |

### 关键参数

| 键 | 建议 | 说明 |
|---|---|---|
| `initial_probability` | 0.05~0.10 | 非 @ 消息的接话概率。0.02 几乎不冒泡，0.3+ 像气氛组 |
| `after_reply_probability` | 0.8 | 接过话后 120 秒内的高概率窗口 |
| `probability_duration` | 120 | 上面的窗口长度（秒） |
| `max_context_messages` | 60 | 插件自建上下文条数。-1 不限，容易喂一堆旧语气 |
| `include_sender_info` | true | 注入"当前对话对象" |
| `include_timestamp` | true | 让模型知道时间 |
| `reply_ai_prompt_mode` | append | 不要覆盖人格 |

### 群级重置

`/gcp_reset_here`：清本群插件上下文 + 设历史截止点，**不删平台对话历史**，但会重启 AstrBot。

**白名单默认是空列表 = 所有人可用。** 必须收紧：

```json
"plugin_gcp_reset_here_allowed_user_ids": ["管理员QQ"],
"plugin_gcp_reset_allowed_user_ids": ["管理员QQ"]
```

### 坑

- `is_at_message` 判定失效 → @ 她不回（见排障文档，必打补丁）
- 与平台 `segmented_reply` 同时开会双重分段
- `enable_private_chat` 保持 false（开发中）

---

## 二、livingmemory（长期记忆）

**作用**：把群聊压缩成可检索的记忆，下次相关时召回注入。

### 必填

| 键 | 填什么 |
|---|---|
| `provider_settings.embedding_provider_id` | 向量模型 provider id |
| `provider_settings.llm_provider_id` | 高推理模型（做记忆抽取） |
| `recall_engine.rerank_provider_id` | 重排 provider 的 **id**，不是模型名 |

### 关键参数

| 键 | 建议 |
|---|---|
| `recall_engine.top_k` | 5 |
| `recall_engine.injection_method` | `extra_user_content`（唯一支持，其它已废弃） |
| `recall_engine.rerank_enabled` | true（有 rerank 就开） |
| `session_manager.enable_full_group_capture` | true |
| `graph_memory.enabled` | true（图记忆，能记住"谁和谁什么关系"） |

### 坑

- `rerank_provider_id` 填成模型名（如 `qwen3-vl-rerank`）会**静默失效**，要填 provider id
- 记忆是第三人称叙述，容易和"当前说话人"混淆 → 人格的人称段要兜住
- 删库重来：停容器，删 `livingmemory.db` / `conversations.db` / `*.index` / `decay_state.json`，启动自动重建

---

## 三、self_learning（好感度 / 心情 / 黑话）

**作用**：给每个群友记好感度，给 bot 记心情，顺带学群里的黑话和表达。

### 必填

| 键 | 填什么 |
|---|---|
| `Model_Configuration.filter_provider_id` | 快速模型（实时过滤/分类） |
| `Model_Configuration.refine_provider_id` | 高推理模型（提炼） |
| `Model_Configuration.reinforce_provider_id` | 高推理模型 |

### 必须关掉的

```json
"Persona_Evolution_Settings": {
  "enable_persona_evolution": false,
  "auto_apply_persona_updates": false,
  "use_persona_manager_updates": false
}
```

**不关会偷偷改写你的人格。** 它会定期把"学到的风格"写回 `personas` 表，
哪怕 prompt 长度没变也可能替换内容。人格是手调的，别交给学习系统。

### 关键参数

| 键 | 建议 | 说明 |
|---|---|---|
| `max_user_affection` | 100 | 单人上限 |
| `max_total_affection` | 9999 | 群总上限。设小会变成零和：有人涨就有人掉 |
| `Mood_System_Settings.mood_persistence_hours` | 2 | 心情刷新周期 |
| `Social_Context_Settings.expression_patterns_hours` | 24 | 只注入 24h 内的表达样本，旧风格自动过期 |
| `Target_Settings.current_persona_name` | 人格名 | 绑定到具体人格 |

### 注入格式（人格要能读懂）

```
【对该用户的好感度】
好感度: 7/100 (初次见面)

【Bot当前情绪状态】
情绪: excited (强度 0.40) - 收到礼物，太兴奋了！
```

分档写死为 0/20/40/60/80，所以人格必须按同样档位写行为，否则中段分数不产生差异。

### 触发规则

好感度**只在 @ 或唤醒消息时结算**。普通群聊不结算，所以"多聊就涨"是错的。

### 可选：每日净增上限

默认**没有**每日上限，理论上可以反复 @ 刷分。要限制的话：

```bash
python scripts/patch_plugins.py --daily-cap 10
```

规则：当天净增不超过 10 点；**当天掉过多少就能多补回来**（掉 12 点则当天上限 22）。
补丁会同时改 config、仓库、facade、数据库管理层、主逻辑和 `_conf_schema.json` 六处，
少一处就不生效。

### 坑

- 心情时长"看起来 24h"其实是因为 `end_time` 没写进库（必打补丁）
- 心情过期不重建，24h 后彻底停止更新（必打补丁）
- 排行榜不排序，按录入顺序显示（必打补丁）
- 好感度下限被钳在 0，负数档永远不会出现

---

## 四、smart_segmentation（分段）

**作用**：把长回复切成多个气泡，像真人打字。

| 键 | 建议 |
|---|---|
| `enabled` | true |
| `provider_id` | 快速模型 |
| `style` | natural |
| `max_segments` | 8 |
| `min_length` | 15 |

与平台 `platform_settings.segmented_reply` **二选一**，同时开会切两次。

---

## 五、四个插件一起跑时的相互影响

| 组合 | 影响 |
|---|---|
| gcp + self_learning | 两者都在用户消息后面注入内容，顺序影响读起来顺不顺 |
| livingmemory + self_learning | 前者注入往事，后者注入关系，可能对同一件事有不同说法 → 以近的为准 |
| smart_segmentation + gcp | gcp 保存历史时可能只存到第一段，属已知限制 |

**人格是三者的共同地基。** 插件只提供状态，怎么表现由人格决定。
