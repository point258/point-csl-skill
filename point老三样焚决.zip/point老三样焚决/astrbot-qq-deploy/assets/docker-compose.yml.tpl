# AstrBot + NapCat 编排模板
# 放到 /opt/bots/docker-compose.yml
# 改三处：时区（可选）、数据目录（可选）、端口（按需）
services:
  napcat:
    image: mlikiowa/napcat-docker:latest
    container_name: napcat
    restart: unless-stopped
    environment:
      NAPCAT_UID: "0"
      NAPCAT_GID: "0"
      MODE: "astrbot"
      TZ: "Asia/Shanghai"
    ports:
      - "6099:6099"          # NapCat WebUI，建议只放行自己 IP
    volumes:
      - ./napcat/config:/app/napcat/config
      - ./napcat/qq:/app/.config/QQ    # 登录态，删了要重新扫码
    networks:
      - botnet

  astrbot:
    image: soulter/astrbot:latest
    container_name: astrbot
    restart: unless-stopped
    environment:
      TZ: "Asia/Shanghai"
    ports:
      - "6185:6185"          # WebUI
      - "6199:6199"          # OneBot 反向 WS，不要放公网
      # - "7833:7833"        # 插件自带的 Web 面板（可选）
    volumes:
      - ./astrbot/data:/AstrBot/data
    networks:
      - botnet

networks:
  botnet:
    driver: bridge

# 启动：cd /opt/bots && docker compose up -d
# 首次登录：前端账号 astrbot，密码在 docker logs astrbot 里打印一次，首次登录强制改密。
#
# 内存只有 1G 的机器先开 swap：
#   fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
#   echo '/swapfile none swap sw 0 0' >> /etc/fstab
